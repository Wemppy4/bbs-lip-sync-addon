package mchorse.bbs_mod.cubic.animation;

import mchorse.bbs_mod.bobj.BOBJBone;
import mchorse.bbs_mod.cubic.IModel;
import mchorse.bbs_mod.cubic.IModelInstance;
import mchorse.bbs_mod.cubic.data.animation.Animation;
import mchorse.bbs_mod.cubic.data.animation.Animations;
import mchorse.bbs_mod.cubic.data.model.Model;
import mchorse.bbs_mod.cubic.data.model.ModelGroup;
import mchorse.bbs_mod.forms.entities.IEntity;
import mchorse.bbs_mod.utils.MathUtils;
import mchorse.bbs_mod.utils.joml.Matrices;
import mchorse.bbs_mod.utils.pose.Transform;
import net.minecraft.class_1304;
import net.minecraft.class_1799;
import net.minecraft.class_243;
import net.minecraft.class_3532;
import net.minecraft.class_4050;
import mchorse.bbs_mod.utils.interps.Lerps;
import java.util.Arrays;
import java.util.List;

public class ProceduralAnimator implements IAnimator
{
    /**
     * {@code BipedEntityModel.setAngles}' riding block, in vanilla's own terms - radians and
     * vanilla's signs - off the 1.20.4 bytecode, the same way the arm poses were taken. Each
     * rig converts them into its own units and directions where they're applied.
     */
    private static final float RIDING_ARM_PITCH = -0.62831855F;
    private static final float RIDING_LEG_PITCH = -1.4137167F;
    private static final float RIDING_LEG_YAW = 0.31415927F;
    private static final float RIDING_LEG_ROLL = 0.07853982F;

    public ActionPlayback basePre;
    public ActionPlayback basePost;

    private IModelInstance model;

    @Override
    public List<String> getActions()
    {
        return Arrays.asList("base_pre", "base_post");
    }

    @Override
    public void setup(IModelInstance model, ActionsConfig actions, boolean fade)
    {
        this.model = model;

        this.basePre = this.createAction(this.basePre, actions.getConfig("base_pre"), true);
        this.basePost = this.createAction(this.basePost, actions.getConfig("base_post"), true);
    }

    /**
     * Create an action with default priority
     */
    public ActionPlayback createAction(ActionPlayback old, ActionConfig config, boolean looping)
    {
        return this.createAction(old, config, looping, 1);
    }

    /**
     * Create an action playback based on given arguments. This method
     * is used for creating actions so it was easier to tell which
     * actions are missing. Besides that, you can pass an old action so
     * in form merging situation it wouldn't interrupt animation.
     */
    public ActionPlayback createAction(ActionPlayback old, ActionConfig config, boolean looping, int priority)
    {
        Animations animations = this.model == null ? null : this.model.getAnimations();

        if (animations == null)
        {
            return null;
        }

        Animation action = animations.get(config.name);

        /* If given action is missing, then omit creation of ActionPlayback */
        if (action == null)
        {
            return null;
        }

        /* If old is the same, then there is no point creating a new one */
        if (old != null && old.action == action)
        {
            old.config = config;
            old.setSpeed(1);

            return old;
        }

        return new ActionPlayback(action, config, looping, priority);
    }

    @Override
    public void update(IEntity entity)
    {
        /* Update primary actions */
        if (this.basePre != null)
        {
            this.basePre.update();
        }

        if (this.basePost != null)
        {
            this.basePost.update();
        }
    }

    @Override
    public void applyActions(IEntity target, IModelInstance armature, float transition)
    {
        if (target == null)
        {
            return;
        }

        if (this.basePre != null)
        {
            this.basePre.apply(target, armature.getModel(), transition, 1F, false);
        }

        IModel model = armature.getModel();
        java.util.Map<String, String> assignments = armature.getProceduralBones();
        String headBone = ProceduralBone.HEAD.resolve(model, assignments);
        String torsoBone = ProceduralBone.TORSO.resolve(model, assignments);
        String rightArmBone = ProceduralBone.RIGHT_ARM.resolve(model, assignments);
        String leftArmBone = ProceduralBone.LEFT_ARM.resolve(model, assignments);
        String rightLegBone = ProceduralBone.RIGHT_LEG.resolve(model, assignments);
        String leftLegBone = ProceduralBone.LEFT_LEG.resolve(model, assignments);
        String anchorBone = ProceduralBone.ANCHOR.resolve(model, assignments);
        class_1799 main = target.getEquipmentStack(class_1304.field_6173);
        class_1799 offhand = target.getEquipmentStack(class_1304.field_6171);

        boolean isRolling = target.getRoll() > 4;
        boolean isInSwimmingPose = target.getEntityPose() == class_4050.field_18079;

        /* Common variables */
        float handSwingProgress = target.getHandSwingProgress(transition);
        float age = target.getAge() + transition;
        float bodyYaw = Lerps.lerp(target.getPrevBodyYaw(), target.getBodyYaw(), transition);
        float headYaw = Lerps.lerp(target.getPrevHeadYaw(), target.getHeadYaw(), transition);
        float yaw = headYaw - bodyYaw;
        float pitch = Lerps.lerp(target.getPrevPitch(), target.getPitch(), transition);
        float limbSpeed = target.getLimbSpeed(transition);
        float limbPhase = target.getLimbPos(transition);
        float leaningPitch = target.getLeaningPitch(transition);

        /* Holding something up stops the swimming stroke - vanilla checks isUsingItem, and a
         * use pose is exactly what that resolves to here. */
        boolean usingItem = ItemUsePose.get(target, true) != null || ItemUsePose.get(target, false) != null;

        float coefficient = 1F;

        if (isRolling)
        {
            coefficient = (float) (target.getVelocity().method_1027() / 0.2D);
            coefficient = Math.max(1F, coefficient * coefficient * coefficient);
        }

        model.resetPose();

        if (target.isSneaking())
        {
            model.applyPose(armature.getSneakingPose());

            /* The code below finalizes bones in euler, and the sneaking pose fully lives in its euler
             * readback — drop the composed orientation so the euler writes stay authoritative. */
            for (ModelGroup group : model.getAllGroups())
            {
                group.orient = null;
            }

            for (BOBJBone bone : model.getAllBOBJBones())
            {
                bone.orient = null;
            }
        }

        /* For regular models */
        if (model instanceof Model)
        {
            ModelGroup leftArm = null;
            ModelGroup rightArm = null;
            ModelGroup leftLeg = null;
            ModelGroup rightLeg = null;
            ModelGroup torso = null;
            ModelGroup headGroup = null;

            for (ModelGroup group : model.getAllGroups())
            {
                if (!anchorBone.isEmpty() && group.id.equals(anchorBone))
                {
                    if (target.isUsingRiptide())
                    {
                        /* Riptide spin was rotate.x·rotate2.y (a pitch then a Y spin
                         * composed after); with rotate2 gone, hold that exact
                         * composition as a quaternion (degrees for cubic current). */
                        group.current.rotationMode = Transform.RotationMode.QUATERNION;
                        group.current.quat.set(Matrices.toQuaternionZYXDegrees(-90.0F - pitch, 0F, 0F)
                            .mul(Matrices.toQuaternionZYXDegrees(0F, age * -75.0F, 0F)));
                    }

                    if (target.isFallFlying())
                    {
                        float roll = target.getRoll() + transition;
                        float riptide = class_3532.method_15363(roll * roll / 100F, 0F, 1F);

                        if (!target.isUsingRiptide())
                        {
                            group.current.rotate.x = riptide * (-90 - pitch);
                        }

                        class_243 look = target.getRotationVec(transition);
                        class_243 velocity = target.lerpVelocity(transition);
                        double vl = velocity.method_37268();
                        double ll = look.method_37268();

                        if (vl > 0 && ll > 0)
                        {
                            double m = (velocity.field_1352 * look.field_1352 + velocity.field_1350 * look.field_1350) / Math.sqrt(vl * ll);
                            double n = velocity.field_1352 * look.field_1350 - velocity.field_1350 * look.field_1352;

                            group.current.rotate.y = MathUtils.toDeg((float)(Math.signum(n) * Math.acos(m)));
                        }
                    }
                    else if (leaningPitch > 0F)
                    {
                        float newPitch = target.isTouchingWater() ? -90F - pitch : -90F;

                        group.current.rotate.x = class_3532.method_16439(leaningPitch, 0F, newPitch);

                        if (target.getEntityPose() == class_4050.field_18079)
                        {
                            group.current.translate.y -= 0.5F * 16F;
                            group.current.translate.z += 0.3F * 16F;
                        }
                    }
                }
                else if (!headBone.isEmpty() && group.id.equals(headBone))
                {
                    headGroup = group;
                    /* The look direction must not erase the authored sneaking head offset. */
                    float sneakX = target.isSneaking() ? group.current.rotate.x - group.initial.rotate.x : 0F;
                    float sneakY = target.isSneaking() ? group.current.rotate.y - group.initial.rotate.y : 0F;
                    if (target.isSneaking()) group.current.rotate.x = group.initial.rotate.x;
                    group.current.rotate.y = -yaw;

                    if (isRolling)
                    {
                        group.current.rotate.x = 45;
                    }
                    else if (leaningPitch > 0F)
                    {
                        group.current.rotate.x = this.lerpAngle(leaningPitch, group.current.rotate.x, isInSwimmingPose ? 45 : -pitch);
                    }
                    else
                    {
                        group.current.rotate.x = -pitch;
                    }
                    group.current.rotate.x += sneakX;
                    group.current.rotate.y += sneakY;
                }
                else if (!rightArmBone.isEmpty() && group.id.equals(rightArmBone))
                {
                    group.current.rotate.x += MathUtils.toDeg(class_3532.method_15362(limbPhase * 0.6662F) * 2.0F * limbSpeed * 0.5F / coefficient);
                    group.current.rotate.z += MathUtils.toDeg(1F * (class_3532.method_15362(-age * 0.09F) * 0.05F + 0.05F));
                    group.current.rotate.x += MathUtils.toDeg(1F * class_3532.method_15374(-age * 0.067F) * 0.05F);

                    rightArm = group;
                }
                else if (!leftArmBone.isEmpty() && group.id.equals(leftArmBone))
                {
                    group.current.rotate.x += MathUtils.toDeg(class_3532.method_15362(limbPhase * 0.6662F + 3.1415927F) * 2.0F * limbSpeed * 0.5F / coefficient);
                    group.current.rotate.z += MathUtils.toDeg(-1F * (class_3532.method_15362(-age * 0.09F) * 0.05F + 0.05F));
                    group.current.rotate.x += MathUtils.toDeg(-1F * class_3532.method_15374(-age * 0.067F) * 0.05F);

                    leftArm = group;
                }
                else if (!torsoBone.isEmpty() && group.id.equals(torsoBone))
                {
                    torso = group;
                }
                else if (!rightLegBone.isEmpty() && group.id.equals(rightLegBone))
                {
                    group.current.rotate.x = MathUtils.toDeg(class_3532.method_15362(limbPhase * 0.6662F + 3.1415927F) * 1.4F * limbSpeed / coefficient);

                    rightLeg = group;
                }
                else if (!leftLegBone.isEmpty() && group.id.equals(leftLegBone))
                {
                    group.current.rotate.x = MathUtils.toDeg(class_3532.method_15362(limbPhase * 0.6662F) * 1.4F * limbSpeed / coefficient);

                    leftLeg = group;
                }
            }

            /* Vanilla seats a rider right here, after the base angles and before the arms are
             * posed: hips up, knees apart, arms dropped. Cubic bones are degrees and read
             * x = -pitch, y = -yaw, z = +roll. */
            if (target.isRiding())
            {
                if (rightArm != null) rightArm.current.rotate.x += -MathUtils.toDeg(RIDING_ARM_PITCH);
                if (leftArm != null) leftArm.current.rotate.x += -MathUtils.toDeg(RIDING_ARM_PITCH);

                if (rightLeg != null)
                {
                    rightLeg.current.rotate.x = -MathUtils.toDeg(RIDING_LEG_PITCH);
                    rightLeg.current.rotate.y = -MathUtils.toDeg(RIDING_LEG_YAW);
                    rightLeg.current.rotate.z = MathUtils.toDeg(RIDING_LEG_ROLL);
                }

                if (leftLeg != null)
                {
                    leftLeg.current.rotate.x = -MathUtils.toDeg(RIDING_LEG_PITCH);
                    leftLeg.current.rotate.y = MathUtils.toDeg(RIDING_LEG_YAW);
                    leftLeg.current.rotate.z = -MathUtils.toDeg(RIDING_LEG_ROLL);
                }
            }

            /* Vanilla poses the arms right here, after the base angles and before
             * the swing: an item lowers the arm, a drawn bow / raised shield /
             * charged crossbow take over both. Cubic bones are degrees and read
             * x = -pitch, y = -yaw (the terms above are written that way). */
            if (leftArm != null && rightArm != null)
            {
                ModelGroup head = headGroup;
                ModelGroup rightGroup = rightArm;
                ModelGroup leftGroup = leftArm;

                VanillaArmPoses.apply(
                    cubicBone(rightGroup), cubicBone(leftGroup),
                    head == null ? MathUtils.toRad(pitch) : -MathUtils.toRad(head.current.rotate.x),
                    head == null ? MathUtils.toRad(yaw) : -MathUtils.toRad(head.current.rotate.y),
                    main, offhand,
                    ItemUsePose.get(target, true), ItemUsePose.get(target, false),
                    target.isSneaking(), handSwingProgress > 0F
                );
            }

            if (handSwingProgress > 0F && torso != null && leftArm != null && rightArm != null)
            {
                ModelGroup group;
                float swingFactor = handSwingProgress;

                torso.current.rotate.y = -MathUtils.toDeg(class_3532.method_15374(class_3532.method_15355(swingFactor) * MathUtils.PI * 2F) * 0.2F);

                leftArm.current.translate.z += (float) Math.sin(MathUtils.toRad(torso.current.rotate.y)) * 5F;
                leftArm.current.translate.x += (float) Math.cos(MathUtils.toRad(torso.current.rotate.y)) * 5F - 5F;
                rightArm.current.translate.z -= (float) Math.sin(MathUtils.toRad(torso.current.rotate.y)) * 5F;
                rightArm.current.translate.x -= (float) Math.cos(MathUtils.toRad(torso.current.rotate.y)) * 5F - 5F;

                group = rightArm;
                group.current.rotate.y += torso.current.rotate.y;
                group = leftArm;
                group.current.rotate.y += torso.current.rotate.y;
                group = leftArm;
                group.current.rotate.x += torso.current.rotate.y;

                swingFactor = 1F - handSwingProgress;
                swingFactor *= swingFactor;
                swingFactor *= swingFactor;
                swingFactor = 1F - swingFactor;

                float headPitch = 0F;
                float swing1 = class_3532.method_15374(swingFactor * MathUtils.PI);
                float swign2 = class_3532.method_15374(handSwingProgress * MathUtils.PI) * -(headPitch - 0.7F) * 0.75F;
                rightArm.current.rotate.x = group.current.rotate.x + MathUtils.toDeg(swing1 * 1.2F + swign2);
                rightArm.current.rotate.y += torso.current.rotate.y * 2F;
                rightArm.current.rotate.z += MathUtils.toDeg(class_3532.method_15374(handSwingProgress * MathUtils.PI) * -0.4F);
            }

            /* Last, the way vanilla does it: the stroke overrides the walk the limbs were given
             * above, weighted by how flat the body has gone. */
            if (leaningPitch > 0F)
            {
                VanillaSwimPose.apply(
                    cubicBone(rightArm), cubicBone(leftArm), cubicBone(rightLeg), cubicBone(leftLeg),
                    leaningPitch, limbPhase, handSwingProgress, usingItem
                );
            }
        }
        /* For BOBJ models */
        else
        {
            BOBJBone bobjLeftArm = null;
            BOBJBone bobjRightArm = null;
            BOBJBone bobjLeftLeg = null;
            BOBJBone bobjRightLeg = null;
            BOBJBone bobjHead = null;
            BOBJBone bobjTorso = null;

            for (BOBJBone bone : model.getAllBOBJBones())
            {
                if (!anchorBone.isEmpty() && bone.name.equals(anchorBone))
                {
                    if (target.isUsingRiptide())
                    {
                        /* See the cubic riptide above; BOBJ channels are radians. */
                        bone.transform.rotationMode = Transform.RotationMode.QUATERNION;
                        bone.transform.quat.set(Matrices.toQuaternionZYXRadians(MathUtils.toRad(-90.0F - pitch), 0F, 0F)
                            .mul(Matrices.toQuaternionZYXRadians(0F, MathUtils.toRad(age * -75.0F), 0F)));
                    }

                    if (target.isFallFlying())
                    {
                        float roll = target.getRoll() + transition;
                        float riptide = class_3532.method_15363(roll * roll / 100F, 0F, 1F);

                        if (!target.isUsingRiptide())
                        {
                            bone.transform.rotate.x = MathUtils.toRad(riptide * (-90 - pitch));
                        }

                        class_243 look = target.getRotationVec(transition);
                        class_243 velocity = target.lerpVelocity(transition);
                        double vl = velocity.method_37268();
                        double ll = look.method_37268();

                        if (vl > 0 && ll > 0)
                        {
                            double m = (velocity.field_1352 * look.field_1352 + velocity.field_1350 * look.field_1350) / Math.sqrt(vl * ll);
                            double n = velocity.field_1352 * look.field_1350 - velocity.field_1350 * look.field_1352;

                            bone.transform.rotate.y = (float)(Math.signum(n) * Math.acos(m));
                        }
                    }
                    else if (leaningPitch > 0F)
                    {
                        float newPitch = target.isTouchingWater() ? -90F - pitch : -90F;

                        bone.transform.rotate.x = MathUtils.toRad(class_3532.method_16439(leaningPitch, 0F, newPitch));

                        if (target.getEntityPose() == class_4050.field_18079)
                        {
                            bone.transform.translate.y -= MathUtils.toRad(0.5F * 16F);
                            bone.transform.translate.z += MathUtils.toRad(0.3F * 16F);
                        }
                    }
                }
                else if (!torsoBone.isEmpty() && bone.name.equals(torsoBone))
                {
                    bobjTorso = bone;
                }
                else if (!headBone.isEmpty() && bone.name.equals(headBone))
                {
                    bobjHead = bone;
                    /* BOBJ pose offsets are already radians; its reset transform is identity. */
                    float sneakX = target.isSneaking() ? bone.transform.rotate.x : 0F;
                    float sneakY = target.isSneaking() ? bone.transform.rotate.y : 0F;
                    if (target.isSneaking()) bone.transform.rotate.x = 0F;
                    bone.transform.rotate.y = MathUtils.toRad(-yaw);

                    if (isRolling)
                    {
                        bone.transform.rotate.x = -MathUtils.toRad(45);
                    }
                    else if (leaningPitch > 0F)
                    {
                        bone.transform.rotate.x = -MathUtils.toRad(this.lerpAngle(leaningPitch, bone.transform.rotate.x, isInSwimmingPose ? 45 : -pitch));
                    }
                    else
                    {
                        bone.transform.rotate.x = -MathUtils.toRad(-pitch);
                    }
                    bone.transform.rotate.x += sneakX;
                    bone.transform.rotate.y += sneakY;
                }
                else if (!rightArmBone.isEmpty() && bone.name.equals(rightArmBone))
                {
                    bone.transform.rotate.x += class_3532.method_15362(limbPhase * 0.6662F) * 2.0F * limbSpeed * 0.5F / coefficient;
                    bone.transform.rotate.z -= 1F * (class_3532.method_15362(-age * 0.09F) * 0.05F + 0.05F);
                    bone.transform.rotate.x += 1F * class_3532.method_15374(-age * 0.067F) * 0.05F;

                    bobjRightArm = bone;
                }
                else if (!leftArmBone.isEmpty() && bone.name.equals(leftArmBone))
                {
                    bone.transform.rotate.x += class_3532.method_15362(limbPhase * 0.6662F + 3.1415927F) * 2.0F * limbSpeed * 0.5F / coefficient;
                    bone.transform.rotate.z -= -1F * (class_3532.method_15362(-age * 0.09F) * 0.05F + 0.05F);
                    bone.transform.rotate.x += -1F * class_3532.method_15374(-age * 0.067F) * 0.05F;

                    bobjLeftArm = bone;
                }
                else if (!rightLegBone.isEmpty() && bone.name.equals(rightLegBone))
                {
                    bone.transform.rotate.x = class_3532.method_15362(limbPhase * 0.6662F + 3.1415927F) * 1.4F * limbSpeed / coefficient;

                    bobjRightLeg = bone;
                }
                else if (!leftLegBone.isEmpty() && bone.name.equals(leftLegBone))
                {
                    bone.transform.rotate.x = class_3532.method_15362(limbPhase * 0.6662F) * 1.4F * limbSpeed / coefficient;

                    bobjLeftLeg = bone;
                }
            }

            /* Same seat for BOBJ rigs: already radians, and their limbs read x = -pitch,
             * y = +yaw, z = -roll (the arm bob above writes them that way). */
            if (target.isRiding())
            {
                if (bobjRightArm != null) bobjRightArm.transform.rotate.x += -RIDING_ARM_PITCH;
                if (bobjLeftArm != null) bobjLeftArm.transform.rotate.x += -RIDING_ARM_PITCH;

                if (bobjRightLeg != null)
                {
                    bobjRightLeg.transform.rotate.x = -RIDING_LEG_PITCH;
                    bobjRightLeg.transform.rotate.y = RIDING_LEG_YAW;
                    bobjRightLeg.transform.rotate.z = -RIDING_LEG_ROLL;
                }

                if (bobjLeftLeg != null)
                {
                    bobjLeftLeg.transform.rotate.x = -RIDING_LEG_PITCH;
                    bobjLeftLeg.transform.rotate.y = -RIDING_LEG_YAW;
                    bobjLeftLeg.transform.rotate.z = RIDING_LEG_ROLL;
                }
            }

            /* Same stage for BOBJ rigs: radians, and their arms read x = -pitch,
             * y = +yaw (the swing block below writes them that way), while their
             * head reads x = +pitch, y = -yaw. */
            if (bobjLeftArm != null && bobjRightArm != null)
            {
                BOBJBone head = bobjHead;

                VanillaArmPoses.apply(
                    bobjBone(bobjRightArm), bobjBone(bobjLeftArm),
                    head == null ? MathUtils.toRad(pitch) : head.transform.rotate.x,
                    head == null ? MathUtils.toRad(yaw) : -head.transform.rotate.y,
                    main, offhand,
                    ItemUsePose.get(target, true), ItemUsePose.get(target, false),
                    target.isSneaking(), handSwingProgress > 0F
                );
            }

            if (handSwingProgress > 0F && bobjLeftArm != null && bobjRightArm != null)
            {
                BOBJBone group;
                float swingFactor = handSwingProgress;
                float rotate = -MathUtils.toDeg(class_3532.method_15374(class_3532.method_15355(swingFactor) * MathUtils.PI * 2F) * 0.2F);

                if (bobjTorso != null) bobjTorso.transform.rotate.y = -MathUtils.toRad(rotate);

                bobjLeftArm.transform.translate.z -= ((float) Math.sin(MathUtils.toRad(rotate)) * 5F) / 16F;
                bobjLeftArm.transform.translate.x -= ((float) Math.cos(MathUtils.toRad(rotate)) * 5F - 5F) / 16F;
                bobjRightArm.transform.translate.z += ((float) Math.sin(MathUtils.toRad(rotate)) * 5F) / 16F;
                bobjRightArm.transform.translate.x += ((float) Math.cos(MathUtils.toRad(rotate)) * 5F - 5F) / 16F;

                group = bobjRightArm;
                group.transform.rotate.y -= MathUtils.toRad(rotate);
                group = bobjLeftArm;
                group.transform.rotate.y -= MathUtils.toRad(rotate);
                group = bobjLeftArm;
                group.transform.rotate.x += MathUtils.toRad(rotate);

                swingFactor = 1F - handSwingProgress;
                swingFactor *= swingFactor;
                swingFactor *= swingFactor;
                swingFactor = 1F - swingFactor;

                float headPitch = 0F;
                float swing1 = class_3532.method_15374(swingFactor * MathUtils.PI);
                float swign2 = class_3532.method_15374(handSwingProgress * MathUtils.PI) * -(headPitch - 0.7F) * 0.75F;
                bobjRightArm.transform.rotate.x = MathUtils.toRad(group.transform.rotate.x + MathUtils.toDeg(swing1 * 1.2F + swign2));
                bobjRightArm.transform.rotate.y -= MathUtils.toRad(rotate * 2F);
                bobjRightArm.transform.rotate.z -= class_3532.method_15374(handSwingProgress * MathUtils.PI) * -0.4F;
            }

            if (leaningPitch > 0F)
            {
                VanillaSwimPose.apply(
                    bobjBone(bobjRightArm), bobjBone(bobjLeftArm), bobjBone(bobjRightLeg), bobjBone(bobjLeftLeg),
                    leaningPitch, limbPhase, handSwingProgress, usingItem
                );
            }
        }

        if (this.basePost != null)
        {
            this.basePost.postApply(target, armature.getModel(), transition);
        }
    }

    /**
     * A cubic bone spoken in vanilla: degrees flipped into radians, x = -pitch, y = -yaw,
     * z = +roll (the arm bob above writes the roll that way).
     */
    private static VanillaBone cubicBone(ModelGroup group)
    {
        if (group == null)
        {
            return null;
        }

        return new VanillaBone()
        {
            @Override
            public float pitch()
            {
                return -MathUtils.toRad(group.current.rotate.x);
            }

            @Override
            public void pitch(float pitch)
            {
                group.current.rotate.x = -MathUtils.toDeg(pitch);
            }

            @Override
            public float yaw()
            {
                return -MathUtils.toRad(group.current.rotate.y);
            }

            @Override
            public void yaw(float yaw)
            {
                group.current.rotate.y = -MathUtils.toDeg(yaw);
            }

            @Override
            public float roll()
            {
                return MathUtils.toRad(group.current.rotate.z);
            }

            @Override
            public void roll(float roll)
            {
                group.current.rotate.z = MathUtils.toDeg(roll);
            }
        };
    }

    /**
     * A BOBJ bone spoken in vanilla: already radians, x = -pitch, y = +yaw, z = -roll.
     */
    private static VanillaBone bobjBone(BOBJBone bone)
    {
        if (bone == null)
        {
            return null;
        }

        return new VanillaBone()
        {
            @Override
            public float pitch()
            {
                return -bone.transform.rotate.x;
            }

            @Override
            public void pitch(float pitch)
            {
                bone.transform.rotate.x = -pitch;
            }

            @Override
            public float yaw()
            {
                return bone.transform.rotate.y;
            }

            @Override
            public void yaw(float yaw)
            {
                bone.transform.rotate.y = yaw;
            }

            @Override
            public float roll()
            {
                return -bone.transform.rotate.z;
            }

            @Override
            public void roll(float roll)
            {
                bone.transform.rotate.z = -roll;
            }
        };
    }

    @Override
    public void playAnimation(String name)
    {}

    protected float lerpAngle(float a, float b, float magnitude)
    {
        float factor = (magnitude - b) % (360);

        if (factor < -180) factor += 360;
        if (factor >= 180) factor -= 360;

        return b + a * factor;
    }
}
