package mchorse.bbs_mod.cubic.animation;

import mchorse.bbs_mod.cubic.animation.ItemUsePose.Use;
import net.minecraft.class_1764;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_3532;

/**
 * Vanilla's arm poses (a drawn bow, a raised shield, a charged crossbow, a
 * lifted trident, a spyglass at the eye) for the procedural animator.
 *
 * <p>Every number here is {@code BipedEntityModel.positionRightArm} /
 * {@code positionLeftArm} / {@code CrossbowPosing} taken off the 1.20.4
 * bytecode, and the pose selection is {@code PlayerEntityRenderer.getArmPose}
 * plus its {@code setModelPose} two-handed rule. The model's bones speak their
 * own units and signs, so they come in through {@link VanillaBone} adapters that talk
 * vanilla: pitch and yaw in radians, vanilla's own directions.</p>
 */
public class VanillaArmPoses
{
    public enum Pose
    {
        EMPTY, ITEM, BLOCK, BOW_AND_ARROW, THROW_SPEAR, CROSSBOW_CHARGE, CROSSBOW_HOLD, SPYGLASS, TOOT_HORN, BRUSH;

        public boolean isTwoHanded()
        {
            return this == BOW_AND_ARROW || this == CROSSBOW_CHARGE || this == CROSSBOW_HOLD;
        }
    }

    /**
     * Poses both arms the way vanilla does at the end of its base angles: the
     * hand that is using something wins alone, otherwise each arm takes the pose
     * of whatever it holds.
     *
     * <p>The actor is right handed (so is the rest of BBS): the right arm gets
     * the main hand, the left arm the off hand.</p>
     */
    public static void apply(VanillaBone right, VanillaBone left, float headPitch, float headYaw, class_1799 main, class_1799 off, Use mainUse, Use offUse, boolean sneaking, boolean swinging)
    {
        Pose rightPose = poseOf(main, mainUse, swinging);
        Pose leftPose = poseOf(off, offUse, swinging);

        /* setModelPose: a two-handed main pose leaves the off hand nothing to do. */
        if (rightPose.isTwoHanded())
        {
            leftPose = off == null || off.method_7960() ? Pose.EMPTY : Pose.ITEM;
        }

        /* Vanilla clears both arms' yaw before posing them; BBS never did, and
         * base animations of existing models live in that yaw. So the yaw is
         * only touched once something is actually being held up - films where
         * nobody uses anything keep the arms they were authored with. */
        boolean strict = mainUse != null || offUse != null || rightPose.isTwoHanded() || leftPose.isTwoHanded();

        if (mainUse != null || offUse != null)
        {
            /* Vanilla positions only the active arm - the other one keeps its
             * plain angles unless the pose itself is two-handed and writes both. */
            boolean mainActive = mainUse != null;

            position(mainActive ? rightPose : leftPose, mainActive, right, left, headPitch, headYaw, sneaking, mainActive ? mainUse : offUse, strict);
        }
        else if (leftPose.isTwoHanded())
        {
            position(leftPose, false, right, left, headPitch, headYaw, sneaking, null, strict);
            position(rightPose, true, right, left, headPitch, headYaw, sneaking, null, strict);
        }
        else
        {
            position(rightPose, true, right, left, headPitch, headYaw, sneaking, null, strict);
            position(leftPose, false, right, left, headPitch, headYaw, sneaking, null, strict);
        }
    }

    /** {@code PlayerEntityRenderer.getArmPose} for one hand. */
    private static Pose poseOf(class_1799 stack, Use use, boolean swinging)
    {
        if (stack == null || stack.method_7960())
        {
            return Pose.EMPTY;
        }

        if (use != null)
        {
            switch (use.action())
            {
                case field_8949: return Pose.BLOCK;
                case field_8953: return Pose.BOW_AND_ARROW;
                case field_8951: return Pose.THROW_SPEAR;
                case field_8947: return Pose.CROSSBOW_CHARGE;
                case field_27079: return Pose.SPYGLASS;
                case field_39058: return Pose.TOOT_HORN;
                case field_42717: return Pose.BRUSH;
                /* Eating and drinking have no pose of their own - vanilla falls through to ITEM. */
                default: break;
            }
        }
        else if (!swinging && stack.method_31574(class_1802.field_8399) && class_1764.method_7781(stack))
        {
            return Pose.CROSSBOW_HOLD;
        }

        return Pose.ITEM;
    }

    private static void position(Pose pose, boolean rightSide, VanillaBone right, VanillaBone left, float headPitch, float headYaw, boolean sneaking, Use use, boolean strict)
    {
        VanillaBone arm = rightSide ? right : left;

        switch (pose)
        {
            case EMPTY:
                if (strict)
                {
                    arm.yaw(0F);
                }

                break;
            case ITEM:
                arm.pitch(arm.pitch() * 0.5F - 0.31415927F);

                if (strict)
                {
                    arm.yaw(0F);
                }

                break;
            case BLOCK:
                arm.pitch(arm.pitch() * 0.5F - 0.9424779F + class_3532.method_15363(headPitch, -1.3962634F, 0.43633232F));
                arm.yaw((rightSide ? -30F : 30F) * 0.017453292F + class_3532.method_15363(headYaw, -0.5235988F, 0.5235988F));

                break;
            case THROW_SPEAR:
                arm.pitch(arm.pitch() * 0.5F - 3.1415927F);
                arm.yaw(0F);

                break;
            case BOW_AND_ARROW:
                right.yaw(-0.1F + headYaw - (rightSide ? 0F : 0.4F));
                left.yaw(0.1F + headYaw + (rightSide ? 0.4F : 0F));
                right.pitch(-1.5707964F + headPitch);
                left.pitch(-1.5707964F + headPitch);

                break;
            case CROSSBOW_CHARGE:
                charge(right, left, rightSide, use);

                break;
            case CROSSBOW_HOLD:
                hold(right, left, rightSide, headPitch, headYaw);

                break;
            case BRUSH:
                arm.pitch(arm.pitch() * 0.5F - 0.62831855F);
                arm.yaw(0F);

                break;
            case SPYGLASS:
                arm.pitch(class_3532.method_15363(headPitch - 1.9198622F - (sneaking ? 0.2617994F : 0F), -2.4F, 3.3F));
                arm.yaw(headYaw + (rightSide ? -0.2617994F : 0.2617994F));

                break;
            case TOOT_HORN:
                arm.pitch(class_3532.method_15363(headPitch, -1.2F, 1.2F) - 1.4835298F);
                arm.yaw(headYaw + (rightSide ? -0.5235988F : 0.5235988F));

                break;
        }
    }

    /** {@code CrossbowPosing.hold}: the crossbow arm aims, the other one steadies it. */
    private static void hold(VanillaBone right, VanillaBone left, boolean rightSide, float headPitch, float headYaw)
    {
        VanillaBone holding = rightSide ? right : left;
        VanillaBone other = rightSide ? left : right;

        holding.yaw((rightSide ? -0.3F : 0.3F) + headYaw);
        other.yaw((rightSide ? 0.6F : -0.6F) + headYaw);
        holding.pitch(-1.5707964F + headPitch + 0.1F);
        other.pitch(-1.5F + headPitch);
    }

    /** {@code CrossbowPosing.charge}: the free arm pulls the string as the charge fills. */
    private static void charge(VanillaBone right, VanillaBone left, boolean rightSide, Use use)
    {
        VanillaBone charging = rightSide ? right : left;
        VanillaBone other = rightSide ? left : right;

        charging.yaw(rightSide ? -0.8F : 0.8F);
        charging.pitch(-0.97079635F);
        other.pitch(charging.pitch());

        float pullTime = use == null ? 25F : Math.max(1, class_1764.method_7775(use.stack()));
        float used = class_3532.method_15363(use == null ? 0F : use.elapsed(), 0F, pullTime);
        float progress = used / pullTime;

        other.yaw(class_3532.method_16439(progress, 0.4F, 0.85F) * (rightSide ? 1F : -1F));
        other.pitch(class_3532.method_16439(progress, other.pitch(), -1.5707964F));
    }
}
