package mchorse.bbs_mod.cubic.weld;

import java.util.List;

/**
 * A weld declared in a model's {@code config.json}: the {@code source} bone's face gets glued onto the
 * {@code target} bone's face, so a two-cube limb (e.g. forearm + fist) keeps its joint sealed when it
 * bends instead of opening the usual box-model gap. Resolved against a model into a {@link WeldBinding}.
 */
public class ModelWeld
{
    public final String sourceBone;
    public final String sourceFace;
    public final String targetBone;
    public final String targetFace;

    /** Largest bend (degrees) the seam keeps following; past it the shear holds so extreme poses don't blow it out. */
    public final float maxAngle;

    /**
     * How far the bend spreads from the seam, as a fraction (0..1) of each welded cube's length along the
     * bone axis. Small values keep the deformation in a thin band right at the joint (the rest of the cube
     * stays rigid); near 1 it spreads across the whole cube the way a plain shear does.
     */
    public final float seamFalloff;

    /**
     * The PARENT bone's share (0..1) of the joint's deformation — anchored to the model hierarchy, not to
     * the weld's source/target roles, so the knob means the same thing however the weld was authored. 0.5
     * puts the seam on the bisector — both cubes crease equally. 0 keeps the parent rigid (an elbow: the
     * upper arm stays hard, the forearm takes the whole fold); 1 is the mirror case. The other bone always
     * takes the remainder, so the joint stays sealed.
     */
    public final float parentShare;

    /** Whether the seam also distributes TWIST (rotation about the bone axis, e.g. a turning wrist) across the band. */
    public final boolean twist;

    /** Whether the two sides share shading normals along the seam, so the crease reads as a rounded edge under light while the geometry stays put. */
    public final boolean smooth;

    /**
     * Which cubes weld to which, picked by hand: with a pair whose both cubes are picked, only the pairs
     * weld; without one, every cube with the welded face does, paired by how the faces fit at rest.
     */
    public final List<Pair> pairs;

    public ModelWeld(String sourceBone, String sourceFace, String targetBone, String targetFace, float maxAngle, float seamFalloff, float parentShare, boolean twist, boolean smooth, List<Pair> pairs)
    {
        this.sourceBone = sourceBone;
        this.sourceFace = sourceFace;
        this.targetBone = targetBone;
        this.targetFace = targetFace;
        this.maxAngle = maxAngle;
        this.seamFalloff = seamFalloff;
        this.parentShare = parentShare;
        this.twist = twist;
        this.smooth = smooth;
        this.pairs = List.copyOf(pairs);
    }

    /** Whether the weld goes by its pairs: one of them has both cubes picked. */
    public boolean picksCubes()
    {
        for (Pair pair : this.pairs)
        {
            if (pair.isPicked())
            {
                return true;
            }
        }

        return false;
    }

    /**
     * A source cube welded to a target cube, each by its place among its bone's cubes (from zero, the
     * order the model lists them in); {@link #NONE} for a side not picked yet.
     */
    public record Pair(int source, int target)
    {
        public static final int NONE = -1;

        public boolean isPicked()
        {
            return this.source >= 0 && this.target >= 0;
        }

        /** The cube of one side: the source's, or the target's. */
        public int side(boolean source)
        {
            return source ? this.source : this.target;
        }

        /** The pair with one side's cube swapped for {@code cube}. */
        public Pair with(boolean source, int cube)
        {
            return source ? new Pair(cube, this.target) : new Pair(this.source, cube);
        }
    }
}
