package mchorse.bbs_mod.cubic.render.vanilla;

import com.google.common.collect.Maps;
import mchorse.bbs_mod.cubic.model.ArmorType;
import mchorse.bbs_mod.forms.entities.IEntity;
import net.minecraft.class_1058;
import net.minecraft.class_1059;
import net.minecraft.class_1092;
import net.minecraft.class_1304;
import net.minecraft.class_1738;
import net.minecraft.class_1741;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1921;
import net.minecraft.class_1937;
import net.minecraft.class_243;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_4057;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_4597;
import net.minecraft.class_4608;
import net.minecraft.class_4722;
import net.minecraft.class_572;
import net.minecraft.class_630;
import net.minecraft.class_8053;
import java.util.Map;

public class ArmorRenderer
{
    private static final Map<String, class_2960> ARMOR_TEXTURE_CACHE = Maps.newHashMap();
    private static final class_2960 ELYTRA_TEXTURE = new class_2960("textures/entity/elytra.png");

    private final class_572 innerModel;
    private final class_572 outerModel;
    private final class_630 elytra;
    private final class_630 elytraLeftWing;
    private final class_630 elytraRightWing;
    private final class_1059 armorTrimsAtlas;

    public ArmorRenderer(class_572 innerModel, class_572 outerModel, class_630 elytra, class_1092 bakery)
    {
        this.innerModel = innerModel;
        this.outerModel = outerModel;
        this.elytra = elytra;
        this.elytraLeftWing = elytra.method_32086("left_wing");
        this.elytraRightWing = elytra.method_32086("right_wing");
        this.armorTrimsAtlas = bakery.method_24153(class_4722.field_42071);
    }

    public void renderArmorSlot(class_4587 matrices, class_4597 vertexConsumers, IEntity entity, class_1304 armorSlot, ArmorType type, int light)
    {
        class_1799 itemStack = entity.getEquipmentStack(armorSlot);
        class_1792 item = itemStack.method_7909();

        if (type == ArmorType.CHEST && itemStack.method_31574(class_1802.field_8833))
        {
            this.renderElytra(matrices, vertexConsumers, entity, itemStack, light);

            return;
        }

        if (item instanceof class_1738 armorItem)
        {
            if (armorItem.method_7685() == armorSlot)
            {
                boolean innerModel = this.usesInnerModel(armorSlot);
                class_572 bipedModel = this.getModel(armorSlot);
                class_630 part = this.getPart(bipedModel, type);

                bipedModel.method_2805(true);

                part.field_3657 = part.field_3656 = part.field_3655 = 0F;
                part.field_3654 = part.field_3675 = part.field_3674 = 0F;
                part.field_37938 = part.field_37939 = part.field_37940 = 1F;

                if (armorItem instanceof class_4057 dyeableArmorItem)
                {
                    int color = dyeableArmorItem.method_7800(itemStack);
                    float r = (float)(color >> 16 & 255) / 255.0F;
                    float g = (float)(color >> 8 & 255) / 255.0F;
                    float b = (float)(color & 255) / 255.0F;

                    this.renderArmorParts(part, matrices, vertexConsumers, light, armorItem, innerModel, r, g, b, null);
                    this.renderArmorParts(part, matrices, vertexConsumers, light, armorItem, innerModel, 1F, 1F, 1F, "overlay");
                }
                else
                {
                    this.renderArmorParts(part, matrices, vertexConsumers, light, armorItem, innerModel, 1F, 1F, 1F, null);
                }

                /* A stub in a preview may have no world of its own; the trims live in the world's
                 * registries, so the client's stands in, and without any world there are no trims. */
                class_1937 world = entity.getWorld() != null ? entity.getWorld() : class_310.method_1551().field_1687;

                if (world != null)
                {
                    class_8053.method_48428(world.method_30349(), itemStack).ifPresent((trim) ->
                    {
                        this.renderTrim(part, armorItem.method_7686(), matrices, vertexConsumers, light, trim, innerModel);
                    });
                }

                if (itemStack.method_7958())
                {
                    this.renderGlint(part, matrices, vertexConsumers, light);
                }
            }
        }
    }

    /* Vanilla elytra, verified against 1.20.4 bytecode: ElytraFeatureRenderer.render
     * (translate 0,0,0.125; armor cutout layer; glint) + ElytraEntityModel.setAngles
     * (non-player branch: standing / sneaking / fall flying wing angles) */
    private void renderElytra(class_4587 matrices, class_4597 vertexConsumers, IEntity entity, class_1799 itemStack, int light)
    {
        float pitch = 0.2617994F;
        float roll = -0.2617994F;
        float pivotY = 0F;
        float yaw = 0F;

        if (entity.isFallFlying())
        {
            float spread = 1F;
            class_243 velocity = entity.getVelocity();

            if (velocity.field_1351 < 0D)
            {
                spread = 1F - (float) Math.pow(-velocity.method_1029().field_1351, 1.5D);
            }

            pitch = spread * 0.34906584F + (1F - spread) * pitch;
            roll = spread * -1.5707964F + (1F - spread) * roll;
        }
        else if (entity.isSneaking())
        {
            pitch = 0.6981317F;
            roll = -0.7853982F;
            pivotY = 3F;
            yaw = 0.08726646F;
        }

        this.elytraLeftWing.field_3656 = pivotY;
        this.elytraLeftWing.field_3654 = pitch;
        this.elytraLeftWing.field_3675 = yaw;
        this.elytraLeftWing.field_3674 = roll;
        this.elytraRightWing.field_3656 = pivotY;
        this.elytraRightWing.field_3654 = pitch;
        this.elytraRightWing.field_3675 = -yaw;
        this.elytraRightWing.field_3674 = -roll;

        matrices.method_22903();
        matrices.method_46416(0F, 0F, 0.125F);

        class_4588 vertexConsumer = vertexConsumers.getBuffer(class_1921.method_25448(ELYTRA_TEXTURE));

        this.elytra.method_22699(matrices, vertexConsumer, light, class_4608.field_21444, 1F, 1F, 1F, 1F);

        if (itemStack.method_7958())
        {
            this.renderGlint(this.elytra, matrices, vertexConsumers, light);
        }

        matrices.method_22909();
    }

    private class_630 getPart(class_572 bipedModel, ArmorType type)
    {
        switch (type)
        {
            case HELMET -> {
                return bipedModel.field_3398;
            }
            case CHEST, LEGGINGS -> {
                return bipedModel.field_3391;
            }
            case LEFT_ARM -> {
                return bipedModel.field_27433;
            }
            case RIGHT_ARM -> {
                return bipedModel.field_3401;
            }
            case LEFT_LEG, LEFT_BOOT -> {
                return bipedModel.field_3397;
            }
            case RIGHT_LEG, RIGHT_BOOT -> {
                return bipedModel.field_3392;
            }
        }

        return bipedModel.field_3398;
    }

    private void renderArmorParts(class_630 part, class_4587 matrices, class_4597 vertexConsumers, int light, class_1738 item, boolean secondTextureLayer, float red, float green, float blue, String overlay)
    {
        class_4588 vertexConsumer = vertexConsumers.getBuffer(class_1921.method_25448(this.getArmorTexture(item, secondTextureLayer, overlay)));

        part.method_22699(matrices, vertexConsumer, light, class_4608.field_21444, red, green, blue, 1F);
    }

    private void renderTrim(class_630 part, class_1741 material, class_4587 matrices, class_4597 vertexConsumers, int light, class_8053 trim, boolean leggings)
    {
        class_1058 sprite = this.armorTrimsAtlas.method_4608(leggings ? trim.method_48434(material) : trim.method_48436(material));
        class_4588 vertexConsumer = sprite.method_24108(vertexConsumers.getBuffer(class_4722.method_48480()));

        part.method_22699(matrices, vertexConsumer, light, class_4608.field_21444, 1F, 1F, 1F, 1F);
    }

    private void renderGlint(class_630 part, class_4587 matrices, class_4597 vertexConsumers, int light)
    {
        part.method_22699(matrices, vertexConsumers.getBuffer(class_1921.method_27949()), light, class_4608.field_21444, 1F, 1F, 1F, 1F);
    }

    private class_572 getModel(class_1304 slot)
    {
        return this.usesInnerModel(slot) ? this.innerModel : this.outerModel;
    }

    private boolean usesInnerModel(class_1304 slot)
    {
        return slot == class_1304.field_6172;
    }

    private class_2960 getArmorTexture(class_1738 item, boolean secondLayer, String overlay)
    {
        String materialName = item.method_7686().method_7694();
        String id = "textures/models/armor/" + materialName + "_layer_" + (secondLayer ? 2 : 1) + (overlay == null ? "" : "_" + overlay) + ".png";

        return ARMOR_TEXTURE_CACHE.computeIfAbsent(id, class_2960::new);
    }
}