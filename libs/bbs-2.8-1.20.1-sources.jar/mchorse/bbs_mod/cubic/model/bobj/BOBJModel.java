package mchorse.bbs_mod.cubic.model.bobj;

import mchorse.bbs_mod.cubic.RigBone;
import mchorse.bbs_mod.bobj.BOBJArmature;
import mchorse.bbs_mod.bobj.BOBJBone;
import mchorse.bbs_mod.bobj.BOBJLoader;
import mchorse.bbs_mod.cubic.IModel;
import mchorse.bbs_mod.cubic.MolangHelper;
import mchorse.bbs_mod.cubic.data.animation.Animation;
import mchorse.bbs_mod.cubic.data.model.ModelGroup;
import mchorse.bbs_mod.cubic.render.vao.BOBJModelSimpleVAO;
import mchorse.bbs_mod.cubic.render.vao.BOBJModelVAO;
import mchorse.bbs_mod.forms.entities.IEntity;
import mchorse.bbs_mod.utils.joml.Matrices;
import mchorse.bbs_mod.utils.pose.Pose;
import mchorse.bbs_mod.utils.pose.PoseTransform;
import mchorse.bbs_mod.utils.pose.Transform;
import org.joml.Vector3f;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class BOBJModel implements IModel
{
    private BOBJArmature armature;
    private List<BOBJLoader.CompiledData> meshes;

    /* One VAO per mesh; each mesh's name is its material for per-mesh texture selection. */
    private List<BOBJModelVAO> vaos = new ArrayList<>();
    private boolean simple;

    /** Bone indices with at least one weighted vertex; lazily filled by {@link #boneDeformsMesh}. */
    private Set<Integer> deformingBones;

    public BOBJModel(BOBJArmature armature, List<BOBJLoader.CompiledData> meshes, boolean simple)
    {
        this.armature = armature;
        this.meshes = meshes;
        this.simple = simple;
    }

    public BOBJArmature getArmature()
    {
        return this.armature;
    }

    /** Rest-pose mesh geometry, also used to frame UI previews. */
    public List<BOBJLoader.CompiledData> getMeshes()
    {
        return Collections.unmodifiableList(this.meshes);
    }

    /**
     * Whether any mesh vertex is weighted to this bone. A bone with no skin is a bare reach marker
     * (an end bone), so IK stretch ends the chain at the last deforming bone instead — the marker
     * would otherwise pull the visible mesh short of the controller. Scans the weights once and caches.
     */
    public boolean boneDeformsMesh(int boneIndex)
    {
        if (this.deformingBones == null)
        {
            this.deformingBones = new HashSet<>();

            for (BOBJLoader.CompiledData mesh : this.meshes)
            {
                int[] indices = mesh.boneIndexData;
                float[] weights = mesh.weightData;

                for (int i = 0; i < indices.length; i++)
                {
                    if (indices[i] >= 0 && weights[i] > 0F)
                    {
                        this.deformingBones.add(indices[i]);
                    }
                }
            }
        }

        return this.deformingBones.contains(boneIndex);
    }

    public List<BOBJModelVAO> getVaos()
    {
        return this.vaos;
    }

    public void delete()
    {
        for (BOBJModelVAO vao : this.vaos)
        {
            vao.delete();
        }

        this.vaos.clear();
    }

    public void setup()
    {
        this.delete();

        for (BOBJLoader.CompiledData mesh : this.meshes)
        {
            this.vaos.add(this.simple ? new BOBJModelSimpleVAO(mesh) : new BOBJModelVAO(mesh));
        }

        this.armature.setupMatrices();
    }

    @Override
    public Pose createPose()
    {
        Pose pose = new Pose();

        for (String key : this.getAllGroupKeys())
        {
            PoseTransform poseTransform = pose.getOrCreate(key);
            BOBJBone group = this.armature.bones.get(key);

            poseTransform.copy(group.transform);
        }

        return pose;
    }

    @Override
    public void resetPose()
    {
        for (BOBJBone orderedBone : this.armature.orderedBones)
        {
            orderedBone.reset();
        }
    }

    @Override
    public void snapshotChannels()
    {
        for (BOBJBone orderedBone : this.armature.orderedBones)
        {
            orderedBone.snapshotChannels();
        }
    }

    @Override
    public void restoreChannels()
    {
        for (BOBJBone orderedBone : this.armature.orderedBones)
        {
            orderedBone.restoreChannels();
        }
    }

    @Override
    public void applyPose(Pose pose)
    {
        if (pose.isEmpty())
        {
            return;
        }

        for (Map.Entry<String, PoseTransform> entry : pose.transforms.entrySet())
        {
            PoseTransform transform = entry.getValue();
            BOBJBone bone = this.armature.bones.get(entry.getKey());

            if (bone == null)
            {
                continue;
            }

            if (transform.fix > 0F)
            {
                bone.transform.lerp(Transform.DEFAULT, transform.fix);

                /* fix blends toward rest, so a composed orientation from earlier layers no longer applies —
                 * drop it and let composeOrient below re-seed from the fix-lerped euler. */
                bone.orient = null;
            }

            // TODO: bone.lighting = transform.lighting;
            bone.visible &= transform.visible;
            // TODO: bone.color.copy(transform.color);
            bone.transform.translate.add(transform.translate);
            bone.transform.scale.add(transform.scale).sub(1, 1, 1);

            if (transform.rotationMode == Transform.RotationMode.QUATERNION)
            {
                /* Quaternion pose: seed orient from the euler so far, compose the
                 * pose quaternion straight in (gimbal-free), keep the euler readback
                 * for gizmo/IK. Mirrors Model.applyPose. */
                if (bone.orient == null)
                {
                    bone.orient = Matrices.toLocalRotationZYXRadians(bone.transform.rotate);
                }

                bone.orient.mul(transform.createRotation());
                bone.transform.rotate.add(Matrices.toEulerZYXRadians(transform.quat, new Vector3f()));
            }
            else
            {
                bone.transform.rotate.add(transform.rotate);

                /* Compose the pose rotation into the orientation quaternion (radians). */
                bone.composeOrient(Matrices.toQuaternionZYXRadians(transform.rotate.x, transform.rotate.y, transform.rotate.z));
            }
        }
    }

    @Override
    public Set<String> getShapeKeys()
    {
        return Set.of();
    }

    @Override
    public String getAnchor()
    {
        for (BOBJBone orderedBone : this.armature.orderedBones)
        {
            if (orderedBone.parentBone != null)
            {
                return orderedBone.name;
            }
        }

        return "";
    }

    @Override
    public Collection<String> getAllGroupKeys()
    {
        return this.armature.bones.keySet();
    }

    @Override
    public Collection<String> getAllChildrenKeys(String key)
    {
        BOBJBone group = this.armature.bones.get(key);
        List<String> groups = new ArrayList<>();

        this.collectChildrenKeys(group, groups);

        return groups;
    }

    private void collectChildrenKeys(BOBJBone group, List<String> groups)
    {
        for (BOBJBone bone : this.armature.orderedBones)
        {
            if (bone.parentBone == group)
            {
                groups.add(bone.name);
                this.collectChildrenKeys(bone, groups);
            }
        }
    }

    @Override
    public Collection<ModelGroup> getAllGroups()
    {
        return Collections.emptyList();
    }

    /** BOBJ armatures are authored facing the other way. */
    @Override
    public boolean isFacingFlipped()
    {
        return true;
    }

    @Override
    public Collection<? extends RigBone> getRigBones()
    {
        return this.getArmature().orderedBones;
    }

    @Override
    public RigBone getBone(String name)
    {
        return this.getArmature().bones.get(name);
    }

    @Override
    public Collection<BOBJBone> getAllBOBJBones()
    {
        return Collections.unmodifiableList(this.armature.orderedBones);
    }

    @Override
    public Collection<String> getAdjacentGroups(String groupName)
    {
        List<String> groups = new ArrayList<>();

        for (BOBJBone orderedBone : this.armature.orderedBones)
        {
            if (orderedBone.parent.equals(groupName))
            {
                groups.add(orderedBone.name);
            }
        }

        return groups;
    }

    @Override
    public Collection<String> getHierarchyGroups(String groupName)
    {
        BOBJBone group = this.armature.bones.get(groupName);
        List<String> groups = new ArrayList<>();

        while (group != null)
        {
            groups.add(group.name);

            group = group.parentBone;
        }

        return groups;
    }

    @Override
    public Collection<String> getRootGroupKeys()
    {
        return this.armature.orderedBones.stream()
            .filter((b) -> b.parent.isEmpty())
            .map((b) -> b.name)
            .toList();
    }

    @Override
    public Collection<String> getDirectChildrenKeys(String key)
    {
        return this.getAdjacentGroups(key);
    }

    @Override
    public String getParentGroupKey(String key)
    {
        BOBJBone bone = this.armature.bones.get(key);

        return bone == null ? "" : bone.parent;
    }

    @Override
    public void apply(IEntity target, Animation action, float tick, float blend, float transition, boolean skipInitial, boolean looping)
    {
        MolangHelper.setMolangVariables(action.parser, target, tick, transition);
        BOBJModelAnimator.animate(this, action, tick, blend, skipInitial, looping);
    }

    @Override
    public void postApply(IEntity target, Animation action, float tick, float transition, boolean looping)
    {
        MolangHelper.setMolangVariables(action.parser, target, tick, transition);
        BOBJModelAnimator.postAnimate(this, action, tick, looping);
    }
}
