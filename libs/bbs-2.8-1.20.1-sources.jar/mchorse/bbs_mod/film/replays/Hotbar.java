package mchorse.bbs_mod.film.replays;

import java.util.Arrays;
import java.util.function.IntFunction;
import net.minecraft.class_1799;

/**
 * The nine hotbar cells at one moment - what a key on a replay's hotbar track holds. A key is
 * the whole row rather than the cells that changed: what the hotbar shows at a tick is simply
 * the key in effect there, nothing is pieced together from earlier ones.
 */
public class Hotbar
{
    private final class_1799[] stacks = new class_1799[ReplayKeyframes.HOTBAR_SIZE];

    public Hotbar()
    {
        Arrays.fill(this.stacks, class_1799.field_8037);
    }

    /** A row filled with copies of what given source holds in each cell. */
    public static Hotbar of(IntFunction<class_1799> source)
    {
        Hotbar hotbar = new Hotbar();

        for (int i = 0; i < ReplayKeyframes.HOTBAR_SIZE; i++)
        {
            hotbar.set(i, source.apply(i).method_7972());
        }

        return hotbar;
    }

    public class_1799 get(int slot)
    {
        return this.stacks[slot];
    }

    public void set(int slot, class_1799 stack)
    {
        this.stacks[slot] = stack == null ? class_1799.field_8037 : stack;
    }

    public boolean isEmpty()
    {
        for (class_1799 stack : this.stacks)
        {
            if (!stack.method_7960())
            {
                return false;
            }
        }

        return true;
    }

    public boolean isSame(Hotbar hotbar)
    {
        for (int i = 0; i < this.stacks.length; i++)
        {
            if (!class_1799.method_7973(this.stacks[i], hotbar.stacks[i]))
            {
                return false;
            }
        }

        return true;
    }

    public Hotbar copy()
    {
        return of(this::get);
    }

    /**
     * The cells as count and item, without their NBT: the same text for equal rows in different
     * copies of a film, which is what code fingerprinting keyframe values by their text needs
     * (NBT can hold runtime state like a gun's ticking).
     */
    @Override
    public String toString()
    {
        return "Hotbar" + Arrays.toString(this.stacks);
    }
}
