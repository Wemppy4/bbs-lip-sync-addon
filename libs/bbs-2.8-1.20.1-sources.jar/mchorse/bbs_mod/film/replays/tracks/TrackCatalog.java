package mchorse.bbs_mod.film.replays.tracks;

import mchorse.bbs_mod.ui.utils.icons.Icon;

import mchorse.bbs_mod.cubic.ModelInstance;
import mchorse.bbs_mod.cubic.ik.ModelIKRuntime;
import mchorse.bbs_mod.film.replays.FormProperties;
import mchorse.bbs_mod.cubic.physics.PhysicsControls;
import mchorse.bbs_mod.cubic.rig.RigStep;
import mchorse.bbs_mod.cubic.spline.SplineIK;
import mchorse.bbs_mod.cubic.spline.SplinePoint;
import mchorse.bbs_mod.forms.FormUtils;
import mchorse.bbs_mod.forms.forms.BodyPart;
import mchorse.bbs_mod.forms.forms.Form;
import mchorse.bbs_mod.cubic.IBoneHierarchy;
import mchorse.bbs_mod.forms.forms.IPosedForm;
import mchorse.bbs_mod.forms.forms.MobForm;
import mchorse.bbs_mod.forms.forms.ModelForm;
import mchorse.bbs_mod.forms.renderers.MobFormRenderer;
import mchorse.bbs_mod.forms.forms.utils.FormMaterial;
import mchorse.bbs_mod.forms.renderers.ModelFormRenderer;
import mchorse.bbs_mod.forms.values.ValueShapeKeys;
import mchorse.bbs_mod.l10n.keys.IKey;
import mchorse.bbs_mod.resources.Link;
import mchorse.bbs_mod.settings.values.base.BaseKeyframeFactoryValue;
import mchorse.bbs_mod.settings.values.base.BaseValue;
import mchorse.bbs_mod.settings.values.base.BaseValueBasic;
import mchorse.bbs_mod.settings.values.core.ValueColor;
import mchorse.bbs_mod.settings.values.core.ValueLink;
import mchorse.bbs_mod.settings.values.core.ValueTransform;
import mchorse.bbs_mod.settings.values.numeric.ValueFloat;
import mchorse.bbs_mod.settings.values.numeric.ValueBoolean;
import mchorse.bbs_mod.settings.values.numeric.ValueInt;
import mchorse.bbs_mod.ui.utils.icons.Icons;
import mchorse.bbs_mod.ui.utils.pose.PoseBones;
import mchorse.bbs_mod.utils.StringUtils;
import mchorse.bbs_mod.utils.colors.Color;
import mchorse.bbs_mod.utils.colors.Colors;
import mchorse.bbs_mod.utils.keyframes.KeyframeChannel;
import mchorse.bbs_mod.utils.pose.PoseTransform;

import java.util.ArrayList;
import java.util.Collection;
import java.util.EnumMap;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * Every track a form tree offers, in the order a timeline shows them.
 *
 * <p>What tracks a form has is a question about the form. It used to be answered by whoever was
 * drawing a timeline: the replay editor walked the form tree one way, the animation state editor
 * repeated the walk with a slightly different subset, and the per-form track filter built a throwaway
 * {@link FormProperties} to ask a third time. Each knew a different set of kinds — which is why the
 * state editor never showed bones or materials, and why the filter listed tracks the timeline didn't.</p>
 *
 * <p>The catalog answers once, as descriptors. A timeline turns those into rows; it no longer decides
 * what exists.</p>
 */
public class TrackCatalog
{
    /** Hues bone tracks are coloured from, one per parent bone, so siblings share a colour. */
    private static final int BONE_TRACK_HUE_COUNT = 12;

    /**
     * The catalog of a form nothing is animating yet — every track it <em>could</em> have, with no
     * channels behind them. Answers "what tracks does this form have" for the per-form track filter,
     * which used to build a throwaway {@link FormProperties} to ask.
     */
    public static List<TrackDescriptor> of(Form root)
    {
        return of(root, null);
    }

    public static List<TrackDescriptor> of(Form root, FormProperties properties)
    {
        List<TrackDescriptor> tracks = new ArrayList<>();

        collect(root, root, "", properties, tracks);
        LegacyTrackCatalog.append(root, properties, tracks);

        return tracks;
    }

    /** Only the selected form's own tracks; nested body parts are selected separately. */
    public static List<TrackDescriptor> forPart(Form root, FormProperties properties, String path)
    {
        List<TrackDescriptor> tracks = of(root, properties);

        tracks.removeIf(track -> !track.id().formPath().equals(path));

        return ordered(tracks);
    }

    /**
     * The catalog laid out the way a timeline draws it: every track that folds under another one
     * follows it directly, so unfolding a parent reveals rows that are already in the right place.
     * A track whose parent is not in the list (a form that has no texture track of its own, say)
     * keeps its position rather than disappearing.
     */
    public static List<TrackDescriptor> ordered(List<TrackDescriptor> tracks)
    {
        Map<TrackId, List<TrackDescriptor>> children = new HashMap<>();
        Map<TrackId, TrackDescriptor> present = new HashMap<>();

        for (TrackDescriptor track : tracks)
        {
            present.put(track.id(), track);

            if (track.parent() != null)
            {
                children.computeIfAbsent(track.parent(), (k) -> new ArrayList<>()).add(track);
            }
        }

        List<TrackDescriptor> out = new ArrayList<>();
        Set<TrackId> appended = new HashSet<>();

        for (TrackDescriptor track : tracks)
        {
            /* Roots only — everything else is reached from its parent, however deep it sits. A bone
             * hangs off a bone that hangs off a bone, so anything that only took direct children
             * would drop the whole skeleton below the first joint. */
            if (track.parent() == null || !present.containsKey(track.parent()))
            {
                /* Pose and its overlays/bones precede the form's transform group. */
                if (track.kind() == TrackKind.PROPERTY && track.id().subject().equals("transform"))
                {
                    TrackDescriptor pose = present.get(TrackId.property(track.id().formPath(), FormProperties.POSE_PROPERTY));

                    if (pose != null && pose.parent() == null && appended.add(pose.id()))
                    {
                        append(pose, children, out);
                    }
                }

                if (appended.add(track.id())) append(track, children, out);
            }
        }

        return out;
    }

    private static void append(TrackDescriptor track, Map<TrackId, List<TrackDescriptor>> children, List<TrackDescriptor> out)
    {
        out.add(track);

        for (TrackDescriptor child : children.getOrDefault(track.id(), List.of()))
        {
            append(child, children, out);
        }
    }

    private static void collect(Form root, Form form, String path, FormProperties properties, List<TrackDescriptor> out)
    {
        if (form == null)
        {
            return;
        }

        ModelInstance model = form instanceof ModelForm modelForm ? ModelFormRenderer.getModel(modelForm) : null;

        properties(root, form, model, path, properties, out);

        if (form instanceof ModelForm modelForm)
        {
            materials(modelForm, model, path, properties, out);
            bones(modelForm, model == null ? null : model.model, model == null ? null : model.getDisabledBones(), path, properties, out);
        }
        else if (form instanceof MobForm mobForm)
        {
            /* A mob form poses the vanilla model's parts, and those are a skeleton like any
             * other - no disabled-bone config behind them, and no per-bone constraints. */
            bones(mobForm, MobFormRenderer.getRig(mobForm), null, path, properties, out);
        }

        /* By the part's stable id, never by its position: the address a track is stored under is
         * built the same way (see FormUtils.getPath), so listing by index would offer tracks whose
         * paths resolve to nothing. */
        for (BodyPart part : form.parts.getAllTyped())
        {
            collect(root, part.getForm(), StringUtils.combinePaths(path, part.getId()), properties, out);
        }
    }


    /** An existing channel, or null. Enumerating tracks never creates animation data. */
    private static KeyframeChannel channel(FormProperties properties, TrackId id)
    {
        return properties == null ? null : properties.get(id);
    }

    /* The form's own properties */

    private static void properties(Form root, Form form, ModelInstance model, String path, FormProperties properties, List<TrackDescriptor> out)
    {
        Map<RigStep, Boolean> used = new EnumMap<>(RigStep.class);

        for (BaseValue value : form.getAll())
        {

            String name = value.getId();
            RigStep step = form instanceof ModelForm ? RigStep.ofTrack(name) : null;

            /* The rig's tracks follow the configured rig, not its animated weight or cached controls
             * (the wind comes with the physics chains it acts on). */
            if (step != null && !used.computeIfAbsent(step, (s) -> s.isUsed((ModelForm) form)))
            {
                continue;
            }

            /* Shape key tracks only apply to models that actually expose shape keys. */
            if (form instanceof ModelForm && value instanceof ValueShapeKeys
                && (model == null || model.model.getShapeKeys().isEmpty()))
            {
                continue;
            }

            /* CEM states belong only to JEM models, including forms nested in body parts. */
            if (form instanceof ModelForm && name.startsWith("cem_") && (model == null || model.cemAnimation == null))
            {
                continue;
            }

            /* Only a property that can hold keyframes is a track — the rest of a form's values are
             * static settings. Asked of the value itself, so it holds with or without a replay. */
            if (!(value instanceof BaseKeyframeFactoryValue<?> animated) || !animated.isAnimatable())
            {
                continue;
            }

            TrackId id = TrackId.property(path, name);
            KeyframeChannel channel = properties == null ? null : properties.get(id);


            BaseValueBasic property = FormUtils.getProperty(root, id.toKey());
            TrackDescriptor track = new TrackDescriptor(id, channel, form, TrackStyle.label(id),
                TrackStyle.icon(name), TrackStyle.color(name), property);

            /* The pose folds only its limbs, the transform nothing: the first overlay of each is a
             * row of its own and folds the additional ones (pose_overlay0, 1…) the settings add. */
            if (name.startsWith("pose_overlay") && !name.equals("pose_overlay"))
            {
                track = track.under(TrackId.property(path, "pose_overlay"));
            }
            else if (name.startsWith("transform_overlay") && !name.equals("transform_overlay"))
            {
                track = track.under(TrackId.property(path, "transform_overlay"));
            }
            else if (name.startsWith("shape_keys_overlay") && !name.equals("shape_keys_overlay"))
            {
                track = track.under(TrackId.property(path, "shape_keys_overlay"));
            }

            if (TrackId.MATERIAL_PROP_OVERLAY.equals(name))
            {
                /* A fresh overlay keyframe must visibly tint — the neutral value has zero strength,
                 * and a keyframe that changes nothing reads as broken. */
                track = track.seed(() -> opaqueOverlaySeed(property.get() instanceof Color color ? color : null));
            }

            out.add(track);
        }
    }

    /* Bones */

    private static void bones(IPosedForm posedForm, IBoneHierarchy iModel, Collection<String> disabledBones, String path, FormProperties properties, List<TrackDescriptor> out)
    {
        if (iModel == null)
        {
            return;
        }

        Form owner = (Form) posedForm;
        TrackId pose = TrackId.property(path, FormProperties.POSE_PROPERTY);
        Map<String, Integer> parentToColor = new HashMap<>();
        Set<String> shown = new HashSet<>();
        int[] hue = {0};

        for (String bone : iModel.getGroupKeysInHierarchyOrder())
        {
            if (PoseBones.isHidden(disabledBones, bone))
            {
                continue;
            }

            shown.add(bone);

            String parent = iModel.getParentGroupKey(bone);
            int color = parentToColor.computeIfAbsent(parent, (p) ->
                Colors.HSVtoRGB((hue[0]++ % BONE_TRACK_HUE_COUNT) / (float) BONE_TRACK_HUE_COUNT, 0.7F, 0.7F).getRGBColor());

            TrackId id = TrackId.bone(path, bone);
            String title = bone;

            /* A bone hangs off the bone it hangs off in the model, so folding an arm folds the whole
             * arm. The root of the skeleton hangs off the form's pose track, which is the thing all
             * of them are contributions to. */
            String ancestor = nearestShown(iModel, shown, parent);

            /* No icon: a skeleton is most of the rows in the timeline, and the same limb icon on every
             * one of them is a column of noise. Their colour already groups them by parent. */
            out.add(new TrackDescriptor(id, channel(properties, id), owner, IKey.constant(title),
                null, color, new ValueTransform(id.toKey(), new PoseTransform()))
                .under(ancestor == null ? pose : TrackId.bone(path, ancestor)));
        }
    }

    /**
     * The closest bone above this one that the timeline is actually showing. A hidden bone is not a
     * row, so its children would have nothing to hang off; they attach to its nearest shown ancestor
     * instead of falling out of the tree.
     */
    private static String nearestShown(IBoneHierarchy model, Set<String> shown, String bone)
    {
        String current = bone;

        while (current != null && !current.isEmpty())
        {
            if (shown.contains(current))
            {
                return current;
            }

            current = model.getParentGroupKey(current);
        }

        return null;
    }

    /* Materials */

    /**
     * The whole-form PBR sliders (which every model has, even a single-material one), plus — for a
     * real material set — one texture track and the appearance tracks per material. All of them fold
     * under the form's own texture track, which is why their titles carry no {@code material/}
     * segment: the track they fold under already says it.
     */
    private static void materials(ModelForm modelForm, ModelInstance model, String path, FormProperties properties, List<TrackDescriptor> out)
    {
        if (model == null)
        {
            return;
        }

        TrackId texture = TrackId.property(path, "texture");

        /* The whole-form material level (the "" key the material tab writes to when no material is
         * selected) owns the PBR sliders of every model — including single-material ones, which have
         * no per-material tracks at all. */
        pbr(modelForm, path, "", modelForm.materials.getMaterial(""), texture, properties, out);

        /* A model with at most one material ignores the material system entirely (its single texture
         * is driven by form.texture), so it exposes no per-material tracks — see the renderer. */
        if (model.materials.size() <= 1)
        {
            return;
        }

        for (String material : model.materials)
        {
            if (material == null || material.isEmpty())
            {
                continue;
            }

            TrackId id = TrackId.materialTexture(path, material);

            /* Seed the track's value with the material's current default texture (editor pick, else
             * folder/Kd, else the form/model default) so a new keyframe starts there instead of null —
             * the texture picker then opens at that texture rather than at the root. */
            Link fallback = modelForm.materialTextures.getLink(material);

            if (fallback == null)
            {
                fallback = model.getMaterialTexture(material, model.getTexture());
            }

            out.add(new TrackDescriptor(id, channel(properties, id), modelForm, IKey.constant(material),
                Icons.MATERIAL, Colors.BLUE, new ValueLink(id.toKey(), fallback))
                .under(texture));

            /* A material's own properties fold under that material, not under the form's texture:
             * one material's sliders have nothing to do with the next material's. */
            materialProps(modelForm, path, material, id, properties, out);
        }
    }

    /**
     * A material's appearance tracks. Each is layered over the static material value at playback, and
     * seeded from it so a fresh keyframe starts at what the material currently shows — except the
     * colour overlay, which seeds at FULL strength: the neutral value has zero strength, and a
     * keyframe that changes nothing reads as broken.
     */
    private static void materialProps(ModelForm modelForm, String path, String material, TrackId parent, FormProperties properties, List<TrackDescriptor> out)
    {
        FormMaterial staticMaterial = modelForm.materials.getMaterial(material);

        TrackId visible = TrackId.materialProp(path, material, TrackId.MATERIAL_PROP_VISIBLE);

        out.add(prop(modelForm, visible, parent, Icons.VISIBLE,
            new ValueBoolean(visible.toKey(), staticMaterial == null || staticMaterial.visible.get()), properties));

        TrackId color = TrackId.materialProp(path, material, TrackId.MATERIAL_PROP_COLOR);

        out.add(prop(modelForm, color, parent, Icons.BUCKET,
            new ValueColor(color.toKey(), staticMaterial == null ? Color.white() : staticMaterial.color.get().copy()), properties));

        TrackId overlay = TrackId.materialProp(path, material, TrackId.MATERIAL_PROP_OVERLAY);
        ValueColor overlayValue = new ValueColor(overlay.toKey(), staticMaterial == null ? new Color(1F, 1F, 1F, 0F) : staticMaterial.overlayColor.get().copy());

        out.add(prop(modelForm, overlay, parent, Icons.COLOR, overlayValue, properties)
            .seed(() -> opaqueOverlaySeed(overlayValue.get())));

        TrackId lighting = TrackId.materialProp(path, material, TrackId.MATERIAL_PROP_LIGHTING);

        out.add(prop(modelForm, lighting, parent, Icons.LIGHT,
            new ValueFloat(lighting.toKey(), staticMaterial == null ? 1F : staticMaterial.lighting.get(), 0F, 1F).slider(), properties));

        TrackId culling = TrackId.materialProp(path, material, TrackId.MATERIAL_PROP_CULLING);

        out.add(prop(modelForm, culling, parent, Icons.CONVERT,
            new ValueInt(culling.toKey(), staticMaterial == null ? 0 : staticMaterial.culling.get()), properties));

        pbr(modelForm, path, material, staticMaterial, parent, properties, out);
    }

    /**
     * The five PBR slider tracks of a material level — used both per material and for the whole-form
     * level (empty material name), which is where a single-material model's sliders live.
     */
    private static void pbr(ModelForm modelForm, String path, String material, FormMaterial staticMaterial, TrackId parent, FormProperties properties, List<TrackDescriptor> out)
    {
        for (String slider : new String[] {
            TrackId.MATERIAL_PROP_SMOOTHNESS, TrackId.MATERIAL_PROP_METALLIC, TrackId.MATERIAL_PROP_SSS,
            TrackId.MATERIAL_PROP_PIXEL_EMISSION, TrackId.MATERIAL_PROP_RELIEF })
        {
            TrackId id = TrackId.materialProp(path, material, slider);
            float value = staticMaterial == null ? 0F : pbrSlider(staticMaterial, slider);

            out.add(prop(modelForm, id, parent, Icons.MATERIAL,
                new ValueFloat(id.toKey(), value, 0F, 1F).slider(), properties));
        }
    }

    /** Named by {@link TrackStyle#label(TrackId)}: a material's sliders keep its name in front, the whole-form level's don't. */
    private static TrackDescriptor prop(ModelForm modelForm, TrackId id, TrackId parent, Icon icon, BaseValueBasic value, FormProperties properties)
    {
        return new TrackDescriptor(id, channel(properties, id), modelForm, TrackStyle.label(id),
            icon, TrackStyle.color(id.property()), value).under(parent);
    }

    private static float pbrSlider(FormMaterial material, String property)
    {
        return switch (property)
        {
            case TrackId.MATERIAL_PROP_SMOOTHNESS -> material.smoothness.get();
            case TrackId.MATERIAL_PROP_METALLIC -> material.metallic.get();
            case TrackId.MATERIAL_PROP_SSS -> material.sss.get();
            case TrackId.MATERIAL_PROP_PIXEL_EMISSION -> material.pixelEmission.get();
            case TrackId.MATERIAL_PROP_RELIEF -> material.relief.get();
            default -> 0F;
        };
    }

    /**
     * The colour overlay's new-keyframe value: the current one when it is already visible, at full
     * strength otherwise — a fresh keyframe must tint, not silently do nothing.
     */
    public static Color opaqueOverlaySeed(Color current)
    {
        Color seed = current == null ? new Color(1F, 1F, 1F, 1F) : current.copy();

        if (seed.a <= 0F)
        {
            seed.a = 1F;
        }

        return seed;
    }

}
