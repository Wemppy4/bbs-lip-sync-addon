package mchorse.bbs_mod;

import mchorse.bbs_mod.api.client.editor.TrackCategories;
import mchorse.bbs_mod.api.client.events.RegisterTrackCategoriesEvent;

import mchorse.bbs_mod.api.client.events.RegisterFilmToolsEvent;
import mchorse.bbs_mod.api.client.events.RegisterFormPanelsEvent;
import mchorse.bbs_mod.api.client.events.RegisterReplayActionsEvent;
import mchorse.bbs_mod.api.client.events.RegisterRigSectionsEvent;

import com.mojang.blaze3d.systems.RenderSystem;
import mchorse.bbs_mod.audio.MinecraftSoundCapture;
import mchorse.bbs_mod.audio.SoundManager;
import mchorse.bbs_mod.blocks.ModelBlock;
import mchorse.bbs_mod.blocks.entities.ModelProperties;
import mchorse.bbs_mod.camera.clips.ClipCategories;
import mchorse.bbs_mod.camera.clips.ClipFactoryData;
import mchorse.bbs_mod.camera.clips.misc.AudioClientClip;
import mchorse.bbs_mod.camera.clips.misc.CurveClientClip;
import mchorse.bbs_mod.camera.clips.misc.TrackerClientClip;
import mchorse.bbs_mod.camera.clips.misc.SplineClientClip;
import mchorse.bbs_mod.camera.clips.misc.VideoClientClip;
import mchorse.bbs_mod.fonts.FontManager;
import mchorse.bbs_mod.video.VideoManager;
import mchorse.bbs_mod.camera.controller.CameraController;
import mchorse.bbs_mod.client.BBSRendering;
import mchorse.bbs_mod.client.ModelBlockConversion;
import mchorse.bbs_mod.client.renderer.LivePlayerItemUse;
import mchorse.bbs_mod.client.renderer.ModelBlockEntityRenderer;
import mchorse.bbs_mod.client.renderer.ThirdPersonItemUse;
import mchorse.bbs_mod.cubic.ModelInstance;
import mchorse.bbs_mod.cubic.animation.ItemUsePose;
import mchorse.bbs_mod.client.renderer.entity.ActorEntityRenderer;
import mchorse.bbs_mod.client.renderer.entity.GunProjectileEntityRenderer;
import mchorse.bbs_mod.client.renderer.item.GunItemRenderer;
import mchorse.bbs_mod.client.renderer.item.ModelBlockItemRenderer;
import mchorse.bbs_mod.cubic.model.ModelManager;
import mchorse.bbs_mod.cubic.rig.RigMarkup;
import mchorse.bbs_mod.api.BBSAddonMod;
import mchorse.bbs_mod.api.client.events.BBSClientReadyEvent;
import mchorse.bbs_mod.api.client.events.RegisterClientSettingsEvent;
import mchorse.bbs_mod.api.client.events.RegisterClipPanelsEvent;
import mchorse.bbs_mod.api.client.events.RegisterClipRenderersEvent;
import mchorse.bbs_mod.api.client.events.RegisterFormSectionsEvent;
import mchorse.bbs_mod.api.client.events.RegisterFrameOverlaysEvent;
import mchorse.bbs_mod.ui.film.FrameOverlays;
import mchorse.bbs_mod.api.client.events.RegisterImportersEvent;
import mchorse.bbs_mod.api.client.events.RegisterKeybindsEvent;
import mchorse.bbs_mod.api.client.events.RegisterModelLoadersEvent;
import mchorse.bbs_mod.api.client.events.RegisterPreviewOverlaysEvent;
import mchorse.bbs_mod.api.client.events.RegisterTrackStylesEvent;
import mchorse.bbs_mod.film.replays.tracks.TrackStyle;
import mchorse.bbs_mod.importers.Importers;
import mchorse.bbs_mod.ui.film.clips.renderer.UIClipRenderers;
import mchorse.bbs_mod.api.client.events.RegisterFormEditorsEvent;
import mchorse.bbs_mod.api.client.events.RegisterFormRenderersEvent;
import mchorse.bbs_mod.api.client.events.RegisterKeyframeEditorsEvent;
import mchorse.bbs_mod.api.client.events.RegisterValueWidgetsEvent;
import mchorse.bbs_mod.forms.FormUtilsClient;
import mchorse.bbs_mod.particles.vanilla.VanillaParticlePreview;
import mchorse.bbs_mod.settings.ui.UIValueMap;
import mchorse.bbs_mod.ui.film.clips.UIClip;
import mchorse.bbs_mod.ui.forms.editors.UIFormEditor;
import mchorse.bbs_mod.ui.framework.elements.input.keyframes.factories.UIKeyframeFactory;
import mchorse.bbs_mod.api.client.events.RegisterL10nEvent;
import mchorse.bbs_mod.film.Films;
import mchorse.bbs_mod.film.Recorder;
import mchorse.bbs_mod.film.WorldVideoExportSession;
import mchorse.bbs_mod.film.replays.Replay;
import mchorse.bbs_mod.forms.FormCategories;
import mchorse.bbs_mod.forms.categories.UserFormCategory;
import mchorse.bbs_mod.forms.forms.Form;
import mchorse.bbs_mod.forms.structure.BakedStructure;
import mchorse.bbs_mod.forms.structure.StructureSelection;
import mchorse.bbs_mod.forms.structure.StructureWand;
import mchorse.bbs_mod.graphics.Draw;
import mchorse.bbs_mod.graphics.FramebufferManager;
import mchorse.bbs_mod.graphics.texture.TextureManager;
import mchorse.bbs_mod.items.GunProperties;
import mchorse.bbs_mod.items.GunZoom;
import mchorse.bbs_mod.l10n.L10n;
import mchorse.bbs_mod.l10n.keys.IKey;
import mchorse.bbs_mod.morphing.Morph;
import mchorse.bbs_mod.network.ClientNetwork;
import mchorse.bbs_mod.network.ServerNetwork;
import mchorse.bbs_mod.particles.ParticleManager;
import mchorse.bbs_mod.resources.AssetProvider;
import mchorse.bbs_mod.resources.Link;
import mchorse.bbs_mod.resources.packs.URLError;
import mchorse.bbs_mod.resources.packs.URLRepository;
import mchorse.bbs_mod.resources.packs.URLSourcePack;
import mchorse.bbs_mod.resources.packs.URLTextureErrorCallback;
import mchorse.bbs_mod.selectors.EntitySelectors;
import mchorse.bbs_mod.ui.UIKeys;
import mchorse.bbs_mod.ui.dashboard.DashboardWarmup;
import mchorse.bbs_mod.ui.dashboard.UIDashboard;
import mchorse.bbs_mod.ui.dashboard.panels.UIDashboardPanels;
import mchorse.bbs_mod.ui.film.UIFilmPanel;
import mchorse.bbs_mod.ui.framework.UIBaseMenu;
import mchorse.bbs_mod.ui.framework.UIScreen;
import mchorse.bbs_mod.ui.model_blocks.UIModelBlockEditorMenu;
import mchorse.bbs_mod.ui.morphing.UIMorphingPanel;
import mchorse.bbs_mod.ui.utils.icons.Icons;
import mchorse.bbs_mod.ui.utils.keys.KeyCombo;
import mchorse.bbs_mod.ui.utils.keys.KeybindSettings;
import mchorse.bbs_mod.utils.MathUtils;
import mchorse.bbs_mod.utils.ScreenshotRecorder;
import mchorse.bbs_mod.utils.VideoRecorder;
import mchorse.bbs_mod.utils.colors.Color;
import mchorse.bbs_mod.utils.colors.Colors;
import net.fabricmc.fabric.api.resource.ResourceManagerHelper;
import net.fabricmc.fabric.api.resource.SimpleSynchronousResourceReloadListener;
import mchorse.bbs_mod.cubic.jem.VanillaRigs;
import mchorse.bbs_mod.utils.resources.CemSourcePack;
import mchorse.bbs_mod.utils.resources.MinecraftSourcePack;
import mchorse.bbs_mod.utils.resources.PlayerSkinSourcePack;
import mchorse.bbs_mod.utils.resources.PlayerSkins;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;
import net.fabricmc.fabric.api.client.rendering.v1.BuiltinItemRendererRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.EntityRendererRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.fabricmc.fabric.api.client.rendering.v1.InvalidateRenderStateCallback;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.fabricmc.fabric.impl.client.rendering.BlockEntityRendererRegistryImpl;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.class_1041;
import net.minecraft.class_1268;
import net.minecraft.class_1304;
import net.minecraft.class_1799;
import net.minecraft.class_286;
import net.minecraft.class_287;
import net.minecraft.class_289;
import net.minecraft.class_290;
import net.minecraft.class_293;
import net.minecraft.class_2960;
import net.minecraft.class_304;
import net.minecraft.class_310;
import net.minecraft.class_3264;
import net.minecraft.class_3300;
import net.minecraft.class_3675;
import net.minecraft.class_4587;
import net.minecraft.class_746;
import net.minecraft.class_757;
import org.lwjgl.glfw.GLFW;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.io.File;
import java.util.Collections;
import java.util.List;

public class BBSModClient implements ClientModInitializer
{
    private static TextureManager textures;
    private static FramebufferManager framebuffers;
    private static SoundManager sounds;
    private static VideoManager videos;
    private static FontManager fonts;
    private static L10n l10n;

    private static ModelManager models;
    private static FormCategories formCategories;
    private static ScreenshotRecorder screenshotRecorder;
    private static VideoRecorder videoRecorder;
    private static final MinecraftSoundCapture minecraftSoundCapture = new MinecraftSoundCapture();
    private static EntitySelectors selectors;

    private static ParticleManager particles;

    private static class_304 keyDashboard;
    private static class_304 keyItemEditor;
    private static class_304 keyPlayFilm;
    private static class_304 keyPauseFilm;
    private static class_304 keyRecordReplay;
    private static class_304 keyRecordVideo;
    private static class_304 keyPlayFilmAndRecord;
    private static class_304 keyOpenReplays;
    private static class_304 keyOpenMorphing;
    private static class_304 keyDemorph;
    private static class_304 keyTeleport;
    private static class_304 keyZoom;

    private static UIDashboard dashboard;

    private static CameraController cameraController = new CameraController();
    private static ModelBlockItemRenderer modelBlockItemRenderer = new ModelBlockItemRenderer();
    private static GunItemRenderer gunItemRenderer = new GunItemRenderer();
    private static Films films;
    private static GunZoom gunZoom;

    private static final WorldVideoExportSession worldExportSession = new WorldVideoExportSession();

    private static float originalFramebufferScale;
    private static boolean customGUIScale;

    /** The OptiFine CEM models of the installed resource packs; null until the client has started. */
    private static CemSourcePack cemSourcePack;

    /** Minecraft's own textures; null until the client has started. */
    private static MinecraftSourcePack minecraftSourcePack;

    public static CemSourcePack getCemSourcePack()
    {
        return cemSourcePack;
    }

    /**
     * Read the resource packs again and drop everything built on what they said before. A pack going
     * on or off changes which models and textures exist, and nothing else would notice: the watchdog
     * watches BBS's own folder, and a link a pack serves has no file behind it to watch.
     */
    private static void reloadFromResourcePacks()
    {
        VanillaParticlePreview.clearCache();

        /* The first reload runs before the client has started; both packs index themselves when made. */
        if (cemSourcePack == null)
        {
            return;
        }

        minecraftSourcePack.setupPaths();
        cemSourcePack.reindex();
        VanillaRigs.clear();

        getModels().forgetFolder(CemSourcePack.NAME + "/");
        getFormCategories().setup();
    }

    public static TextureManager getTextures()
    {
        return textures;
    }

    public static FramebufferManager getFramebuffers()
    {
        return framebuffers;
    }

    public static SoundManager getSounds()
    {
        return sounds;
    }

    public static VideoManager getVideos()
    {
        return videos;
    }

    public static FontManager getFonts()
    {
        return fonts;
    }

    public static L10n getL10n()
    {
        return l10n;
    }

    public static ModelManager getModels()
    {
        return models;
    }

    public static FormCategories getFormCategories()
    {
        return formCategories;
    }

    public static ScreenshotRecorder getScreenshotRecorder()
    {
        return screenshotRecorder;
    }

    public static VideoRecorder getVideoRecorder()
    {
        return videoRecorder;
    }

    public static MinecraftSoundCapture getMinecraftSoundCapture()
    {
        return minecraftSoundCapture;
    }

    public static EntitySelectors getSelectors()
    {
        return selectors;
    }

    public static ParticleManager getParticles()
    {
        return particles;
    }

    public static CameraController getCameraController()
    {
        return cameraController;
    }

    public static Films getFilms()
    {
        return films;
    }

    public static GunZoom getGunZoom()
    {
        return gunZoom;
    }

    public static class_304 getKeyZoom()
    {
        return keyZoom;
    }

    public static class_304 getKeyRecordVideo()
    {
        return keyRecordVideo;
    }

    public static boolean isVideoExportDelayPending()
    {
        return worldExportSession.isWarmingUp();
    }

    public static long getVideoExportDelayRemainingMs()
    {
        return worldExportSession.getWarmupRemainingMs();
    }

    /** Returns the dashboard without creating it. Used to avoid creating UI when handling keys (e.g. F6) before user has opened BBS. */
    public static UIDashboard getDashboardIfCreated()
    {
        if (dashboard != null)
        {
            dashboard.finishBuilding();
        }

        return dashboard;
    }

    public static UIDashboard getDashboard()
    {
        UIDashboard dashboard = getUnfinishedDashboard();

        dashboard.finishBuilding();

        return dashboard;
    }

    /**
     * The dashboard, created if it wasn't there, but not necessarily built in full.
     *
     * <p>Only {@link DashboardWarmup}, which is what finishes it a step at a time, has any
     * business with a half built dashboard — everybody else wants {@link #getDashboard()}.</p>
     */
    public static UIDashboard getUnfinishedDashboard()
    {
        if (dashboard == null)
        {
            dashboard = new UIDashboard();
        }

        return dashboard;
    }

    /**
     * The world is gone: nothing of this session may reach the next one.
     *
     * <p>Called at the end of the game's own disconnect (see {@code MinecraftClientMixin}), on the
     * client thread. It used to be a task queued from Fabric's disconnect event, which comes from
     * Netty's thread - but the game's disconnect empties the client's task queue, and a task that
     * got in before that was dropped without a trace: the next world then got this dashboard, with
     * the old world's film still open in it, and its first save wrote that film into the new world.</p>
     */
    public static void leaveWorld()
    {
        dashboard = null;
        DashboardWarmup.reset();
        worldExportSession.stop();
        videos.delete();

        /* Corners are raw coordinates: kept across a world change they would point the wand
         * at whatever now stands in their place */
        StructureSelection.clear();

        /* A panel export dies with its dashboard without finishing - the sound
         * capture must not keep accumulating into the next session */
        minecraftSoundCapture.end();

        films = new Films();

        ClientNetwork.resetHandshake();
        films.reset();
        cameraController.reset();
        BBSResources.leaveWorld();
    }

    /**
     * Whether BBS's UI is on screen right now, i.e. whether the ui_scale setting
     * should drive the window's scale factor (see WindowMixin).
     */
    public static void setCustomGUIScale(boolean enabled)
    {
        customGUIScale = enabled;
    }

    /**
     * GUI scale that should be forced upon the window, or 0 to leave
     * Minecraft's own scale in charge (BBS UI closed, or ui_scale is 0).
     */
    public static float getCustomGUIScale()
    {
        return customGUIScale ? BBSSettings.userIntefaceScale.get() : 0F;
    }

    /**
     * The scale at which GUI is being rendered right now (GUI pixels to
     * framebuffer pixels). Unlike the ui_scale setting itself, this is always
     * the actual applied value, including the "0 = Minecraft's scale" mode.
     */
    public static float getGUIScale()
    {
        return (float) class_310.method_1551().method_22683().method_4495();
    }

    public static float getOriginalFramebufferScale()
    {
        return Math.max(originalFramebufferScale, 1);
    }

    public static ModelProperties getItemStackProperties(class_1799 stack)
    {
        ModelBlockItemRenderer.Item item = modelBlockItemRenderer.get(stack);

        if (item != null)
        {
            return item.entity.getProperties();
        }

        GunItemRenderer.Item gunItem = gunItemRenderer.get(stack);

        if (gunItem != null)
        {
            return gunItem.properties;
        }

        return null;
    }

    public static void onEndKey(long window, int key, int scancode, int action, int modifiers, CallbackInfo info)
    {
        if (action != GLFW.GLFW_PRESS)
        {
            return;
        }

        class_746 player = class_310.method_1551().field_1724;

        if (player == null || class_310.method_1551().field_1755 != null)
        {
            return;
        }

        Morph morph = Morph.getMorph(player);

        /* Animation state trigger */
        if (morph != null && morph.getForm() != null && morph.getForm().findState(key, (form, state) ->
        {
            ClientNetwork.sendFormTrigger(state.id.get(), ServerNetwork.STATE_TRIGGER_MORPH);
            form.playState(state);
        }))
            return;

        /* Animation state trigger for items*/
        ModelProperties main = getItemStackProperties(player.method_5998(class_1268.field_5808));
        ModelProperties offhand = getItemStackProperties(player.method_5998(class_1268.field_5810));

        if (main != null && main.getForm() != null && main.getForm().findState(key, (form, state) ->
        {
            ClientNetwork.sendFormTrigger(state.id.get(), ServerNetwork.STATE_TRIGGER_MAIN_HAND_ITEM);
            form.playState(state);
        }))
            return;

        if (offhand != null && offhand.getForm() != null && offhand.getForm().findState(key, (form, state) ->
        {
            ClientNetwork.sendFormTrigger(state.id.get(), ServerNetwork.STATE_TRIGGER_OFF_HAND_ITEM);
            form.playState(state);
        }))
            return;

        /* Change form based on the hotkey */
        for (Form form : BBSModClient.getFormCategories().getRecentForms().getCategories().get(0).getForms())
        {
            if (form.hotkey.get() == key)
            {
                ClientNetwork.sendPlayerForm(form);

                return;
            }
        }

        for (UserFormCategory category : BBSModClient.getFormCategories().getUserForms().categories)
        {
            for (Form form : category.getForms())
            {
                if (form.hotkey.get() == key)
                {
                    ClientNetwork.sendPlayerForm(form);

                    return;
                }
            }
        }
    }

    @Override
    public void onInitializeClient()
    {
        /* Every resource reload: the pack list changed, or the user pressed F3+T. It fires before the
         * client has started too, which reloadFromResourcePacks sits out. */
        ResourceManagerHelper.get(class_3264.field_14188).registerReloadListener(new SimpleSynchronousResourceReloadListener()
        {
            @Override
            public class_2960 getFabricId()
            {
                return new class_2960(BBSMod.MOD_ID, "resource_pack_models");
            }

            @Override
            public void method_14491(class_3300 manager)
            {
                reloadFromResourcePacks();
            }
        });

        /* The client half of the addons, picked up before anything client side is posted. Their
         * common half is registered by BBSMod, from the "bbs-addon" entrypoint. */
        FabricLoader.getInstance()
            .getEntrypointContainers("bbs-client-addon", BBSAddonMod.class)
            .forEach((container) ->
            {
                BBSMod.events.register(container.getEntrypoint());
            });

        AssetProvider provider = BBSMod.getProvider();

        textures = new TextureManager(provider);
        framebuffers = new FramebufferManager();
        sounds = new SoundManager(provider);
        videos = new VideoManager();
        fonts = new FontManager();
        l10n = new L10n();
        l10n.register((lang) -> Collections.singletonList(Link.assets("strings/" + lang + ".json")));

        /* Addons add their own language files here, so the event goes out before the load and not
         * after it — otherwise every addon label would show its raw key until the next language
         * switch, or every addon would have to reload the whole thing a second time. */
        BBSMod.events.post(new RegisterL10nEvent(l10n));

        l10n.reload();

        File parentFile = BBSMod.getSettingsFolder().getParentFile();

        particles = new ParticleManager(() -> new File(BBSMod.getAssetsFolder(), "particles"), BBSMod.getDynamicSourcePack());

        /* Both of these are read by the objects made right below, and both lists are rebuilt
         * on every asset reload — so the moment to add to them is before the first build. */
        BBSMod.events.post(new RegisterModelLoadersEvent());
        BBSMod.events.post(new RegisterFormSectionsEvent());

        models = new ModelManager(provider);
        formCategories = new FormCategories();
        screenshotRecorder = new ScreenshotRecorder(new File(parentFile, "screenshots"));
        videoRecorder = new VideoRecorder();
        selectors = new EntitySelectors();
        selectors.read();
        films = new Films();

        BBSResources.init();

        /* While the dashboard is open or a model block is held, model blocks
         * are targetable as at least a full cube even with a tiny hitbox. */
        ModelBlock.editingCheck = () ->
        {
            if (UIScreen.getCurrentMenu() instanceof UIDashboard)
            {
                return true;
            }

            class_310 mc = class_310.method_1551();

            return mc.field_1724 != null && mc.field_1724.method_6047().method_31574(BBSMod.MODEL_BLOCK_ITEM);
        };

        URLRepository repository = new URLRepository(new File(parentFile, "url_cache"));

        provider.register(new URLSourcePack("http", repository));
        provider.register(new URLSourcePack("https", repository));

        PlayerSkins.init(new File(parentFile, "skin_cache"));

        provider.register(new PlayerSkinSourcePack());

        BBSMod.events.post(new RegisterTrackCategoriesEvent());
        TrackCategories.finishRegistration();

        KeybindSettings.registerClasses();

        BBSMod.events.post(new RegisterKeybindsEvent());

        KeybindSettings.migrateTrackSearchShortcuts(BBSMod.setupConfig(Icons.KEY_CAP, "keybinds",
            new File(BBSMod.getSettingsFolder(), "keybinds.json"), KeybindSettings::register));

        BBSMod.events.post(new RegisterClientSettingsEvent());

        BBSSettings.language.postCallback((v, f) -> reloadLanguage(getLanguageKey()));
        BBSSettings.userIntefaceScale.postCallback((v, f) ->
        {
            class_310 mc = class_310.method_1551();

            if (mc.field_1755 instanceof UIScreen)
            {
                mc.method_15993();
            }
        });
        BBSSettings.editorSeconds.postCallback((v, f) ->
        {
            if (dashboard != null && dashboard.getPanels().panel instanceof UIFilmPanel panel)
            {
                panel.fillData();
            }
        });

        BBSSettings.taskbarSide.postCallback((v, f) ->
        {
            if (dashboard != null)
            {
                dashboard.getPanels().setSide(UIDashboardPanels.getSettingsSide());
            }
        });

        BBSSettings.welds.postCallback((v, f) ->
        {
            for (ModelInstance model : models.models.values())
            {
                model.refreshWelds();
            }
        });

        BBSSettings.taskbarSide.modes(UIDashboardPanels.getSideLabels());

        BBSSettings.keystrokeMode.modes(
            UIKeys.ENGINE_KEYSTROKES_POSITION_AUTO,
            UIKeys.ENGINE_KEYSTROKES_POSITION_BOTTOM_LEFT,
            UIKeys.ENGINE_KEYSTROKES_POSITION_BOTTOM_RIGHT,
            UIKeys.ENGINE_KEYSTROKES_POSITION_TOP_RIGHT,
            UIKeys.ENGINE_KEYSTROKES_POSITION_TOP_LEFT
        );

        BBSSettings.rotate3dSphereMode.modes(
            UIKeys.ENGINE_ROTATE_3D_SPHERE_MODE_TRACKBALL,
            UIKeys.ENGINE_ROTATE_3D_SPHERE_MODE_ARCBALL
        );

        BBSSettings.translateHotkeyOrder
            .labels(
                UIKeys.TRANSFORMS_TARGET_SCREEN,
                IKey.constant("X"),
                IKey.constant("Y"),
                IKey.constant("Z")
            )
            .colors(0, Colors.A100 | Colors.RED, Colors.A100 | Colors.GREEN, Colors.A100 | Colors.BLUE);

        BBSSettings.scaleHotkeyOrder
            .labels(
                UIKeys.TRANSFORMS_TARGET_ALL,
                IKey.constant("X"),
                IKey.constant("Y"),
                IKey.constant("Z")
            )
            .colors(0, Colors.A100 | Colors.RED, Colors.A100 | Colors.GREEN, Colors.A100 | Colors.BLUE);

        BBSSettings.rotateHotkeyOrder
            .labels(
                UIKeys.TRANSFORMS_TARGET_VIEW,
                UIKeys.TRANSFORMS_TARGET_SPHERE,
                IKey.constant("X"),
                IKey.constant("Y"),
                IKey.constant("Z")
            )
            .colors(0, 0, Colors.A100 | Colors.RED, Colors.A100 | Colors.GREEN, Colors.A100 | Colors.BLUE);

        UIKeys.C_KEYBIND_CATGORIES.load(KeyCombo.getCategoryKeys());
        UIKeys.C_KEYBIND_CATGORIES_TOOLTIP.load(KeyCombo.getCategoryKeys());

        /* Replace audio clip with client version that plays audio */
        BBSMod.getFactoryCameraClips()
            .register(Link.bbs("audio"), AudioClientClip.class, new ClipFactoryData(Icons.SOUND, 0xffc825).in(ClipCategories.MISC))
            .register(Link.bbs("video"), VideoClientClip.class, new ClipFactoryData(Icons.VIDEO_CAMERA, 0xd21f3c).in(ClipCategories.MISC))
            .register(Link.bbs("tracker"), TrackerClientClip.class, new ClipFactoryData(Icons.USER, 0x4cedfc).in(ClipCategories.OVERWRITE))
            .register(Link.bbs("spline"), SplineClientClip.class, new ClipFactoryData(Icons.GRAPH, 0x5599ff).in(ClipCategories.OVERWRITE))
            .register(Link.bbs("curve"), CurveClientClip.class, new ClipFactoryData(Icons.ARC, 0xff1493).in(ClipCategories.MISC));

        /* The client-side registries, each followed by the event that lets addons add to it.
         * They used to fill themselves in static initialisers, so the moment depended on who
         * touched the class first — a moment nobody chose and an addon could not aim at. */
        FormUtilsClient.setup();
        BBSMod.events.post(new RegisterFormRenderersEvent());

        UIFormEditor.setup();
        BBSMod.events.post(new RegisterFormEditorsEvent());
        BBSMod.events.post(new RegisterFormPanelsEvent());
        BBSMod.events.post(new RegisterRigSectionsEvent());
        BBSMod.events.post(new RegisterReplayActionsEvent());

        UIClip.setup();
        BBSMod.events.post(new RegisterClipPanelsEvent());

        UIKeyframeFactory.setup();
        BBSMod.events.post(new RegisterKeyframeEditorsEvent());

        UIValueMap.setup();
        BBSMod.events.post(new RegisterValueWidgetsEvent());

        UIClipRenderers.setup();
        BBSMod.events.post(new RegisterClipRenderersEvent());

        TrackStyle.setup();
        BBSMod.events.post(new RegisterTrackStylesEvent());

        Importers.setup();
        BBSMod.events.post(new RegisterImportersEvent());

        FrameOverlays.setup();
        BBSMod.events.post(new RegisterFrameOverlaysEvent());

        BBSMod.events.post(new RegisterPreviewOverlaysEvent());
        BBSMod.events.post(new RegisterFilmToolsEvent());

        /* Keybinds */
        keyDashboard = this.createKey("dashboard", GLFW.GLFW_KEY_0);
        keyItemEditor = this.createKey("item_editor", GLFW.GLFW_KEY_HOME);
        keyPlayFilm = this.createKey("play_film", GLFW.GLFW_KEY_RIGHT_CONTROL);
        keyPauseFilm = this.createKey("pause_film", GLFW.GLFW_KEY_BACKSLASH);
        keyRecordReplay = this.createKey("record_replay", GLFW.GLFW_KEY_RIGHT_ALT);
        keyRecordVideo = this.createKey("record_video", GLFW.GLFW_KEY_F4);
        keyPlayFilmAndRecord = this.createKey("play_film_and_record", GLFW.GLFW_KEY_F6);
        keyOpenReplays = this.createKey("open_replays", GLFW.GLFW_KEY_RIGHT_SHIFT);
        keyOpenMorphing = this.createKey("open_morphing", GLFW.GLFW_KEY_B);
        keyDemorph = this.createKey("demorph", GLFW.GLFW_KEY_PERIOD);
        keyTeleport = this.createKey("teleport", GLFW.GLFW_KEY_Y);
        keyZoom = this.createKeyMouse("zoom", 2);

        StructureWand.register();
        ModelBlockConversion.register();

        /* The rig's markup the film viewport draws is what this world frame rendered */
        WorldRenderEvents.START.register((context) -> RigMarkup.beginWorld());
        WorldRenderEvents.END.register((context) -> RigMarkup.endWorld());
        WorldRenderEvents.BEFORE_ENTITIES.register((context) -> BBSRendering.beginEntityPass());

        WorldRenderEvents.AFTER_ENTITIES.register((context) ->
        {
            StructureWand.renderWorld(context);

            if (!BBSRendering.isIrisShadersEnabled())
            {
                BBSRendering.renderCoolStuff(context);
            }

            BBSRendering.endEntityPass();

            if (BBSSettings.chromaSkyEnabled.get())
            {
                float d = BBSSettings.chromaSkyBillboard.get();

                if (d > 0)
                {
                    class_4587 stack = context.matrixStack();
                    Integer fromCurve = BBSRendering.getChromaSkyColorArgb();
                    Color color = Colors.COLOR.set(fromCurve != null ? fromCurve : BBSSettings.chromaSkyColor.get());

                    stack.method_22903();

                    class_4587.class_4665 peek = stack.method_23760();

                    peek.method_23761().identity();
                    peek.method_23762().identity();
                    stack.method_46416(0F, 0F, -d);

                    RenderSystem.enableDepthTest();
                    class_287 builder = class_289.method_1348().method_1349();

                    builder.method_1328(class_293.class_5596.field_27379, class_290.field_1576);

                    float fov = class_310.method_1551().field_1690.method_41808().method_41753();
                    float dd = d * (float) Math.pow(fov / 40F, 2F);

                    Draw.fillQuad(builder, stack,
                        -dd, -dd, 0,
                        dd, -dd, 0,
                        dd, dd, 0,
                        -dd, dd, 0,
                        color.r, color.g, color.b, 1F
                    );

                    RenderSystem.setShader(class_757::method_34540);

                    class_286.method_43433(builder.method_1326());
                    RenderSystem.disableDepthTest();

                    stack.method_22909();
                }
            }
        });

        /* The procedural animator poses actor arms from the film's use state
         * (a drawn bow, a raised shield), and that state is computed here on
         * the client - hand it the lookup. */
        ItemUsePose.setSource(ThirdPersonItemUse::get);

        ClientPlayConnectionEvents.JOIN.register((handler, sender, client) -> client.execute(() ->
        {
            if (client.method_1562() == handler)
            {
                BBSResources.enterWorld();
            }
        }));

        ClientTickEvents.START_CLIENT_TICK.register((client) ->
        {
            /* The frame is over: outside of drawing, the player is themselves
             * again and nothing of the film's use answers for them */
            LivePlayerItemUse.endFrame();

            videos.update();
            sounds.update();
            fonts.update();

            BBSRendering.startTick();

            getFormCategories().getUserForms().flush();
        });

        ClientTickEvents.END_WORLD_TICK.register((client) ->
        {
            class_310 mc = class_310.method_1551();

            if (!mc.method_1493())
            {
                films.updateEndWorld();
            }

        });

        ClientTickEvents.END_CLIENT_TICK.register((client) ->
        {
            class_310 mc = class_310.method_1551();

            /* Files can change while an editor or the unfocused game pauses world ticks. */
            BBSResources.tick();

            if (mc.field_1755 instanceof UIScreen screen)
            {
                screen.update();
            }

            cameraController.update();

            if (!mc.method_1493())
            {
                films.update();
                modelBlockItemRenderer.update();
                gunItemRenderer.update();
            }

            /* Animated textures keep going in BBS's own screens even while the game is paused
             * under them — the texture manager pauses it, the film editor doesn't, and a preview
             * should play in both. With no BBS screen the clock stops with the world, as vanilla's does. */
            if (!mc.method_1493() || mc.field_1755 instanceof UIScreen)
            {
                textures.update();
            }

            worldExportSession.update();

            /* Build the dashboard while nothing is asking for it, so that the key below
             * opens one that is already there */
            DashboardWarmup.tick(mc);

            while (keyDashboard.method_1436()) UIScreen.open(getDashboard());
            while (keyItemEditor.method_1436()) this.keyOpenModelBlockEditor(mc);
            while (keyPlayFilm.method_1436()) this.keyPlayFilm();
            while (keyPauseFilm.method_1436()) this.keyPauseFilm();
            while (keyRecordReplay.method_1436()) this.keyRecordReplay();
            while (keyRecordVideo.method_1436()) this.keyRecordVideo(mc);
            while (keyPlayFilmAndRecord.method_1436()) this.keyPlayFilmAndRecord();
            while (keyOpenReplays.method_1436()) this.keyOpenReplays();
            while (keyOpenMorphing.method_1436())
            {
                UIDashboard dashboard = getDashboard();

                UIScreen.open(dashboard);
                dashboard.setPanel(dashboard.getPanel(UIMorphingPanel.class));
            }
            while (keyDemorph.method_1436()) ClientNetwork.sendPlayerForm(null);
            while (keyTeleport.method_1436()) this.keyTeleport();

            if (mc.field_1724 != null)
            {
                boolean zoom = keyZoom.method_1434();
                class_1799 stack = mc.field_1724.method_6047();

                if (gunZoom == null && zoom && stack.method_7909() == BBSMod.GUN_ITEM)
                {
                    GunProperties properties = GunProperties.get(stack);

                    ClientNetwork.sendZoom(true);
                    gunZoom = new GunZoom(properties.fovTarget, properties.fovInterp, properties.fovDuration);
                }
            }
        });

        /* Baked structures hold sprite UVs — stale after resource reload (pack switch, F3+A) */
        InvalidateRenderStateCallback.EVENT.register(BakedStructure::invalidateAll);

        HudRenderCallback.EVENT.register((drawContext, tickDelta) ->
        {
            BBSRendering.renderHud(drawContext, tickDelta);

            if (gunZoom != null)
            {
                gunZoom.update(keyZoom.method_1434(), class_310.method_1551().method_1534());

                if (gunZoom.canBeRemoved())
                {
                    ClientNetwork.sendZoom(false);
                    gunZoom = null;
                }
            }
        });

        ClientLifecycleEvents.CLIENT_STOPPING.register((e) -> BBSResources.stopWatchdog());
        ClientLifecycleEvents.CLIENT_STARTED.register((e) ->
        {
            BBSRendering.setupFramebuffer();

            minecraftSourcePack = new MinecraftSourcePack();

            provider.register(minecraftSourcePack);

            /* Last under "assets", so the user's own folder and the jar win over a resource pack's
             * models - which is what lets a pack model be given a config.json or replaced outright. */
            cemSourcePack = new CemSourcePack();

            provider.register(cemSourcePack);

            class_1041 window = class_310.method_1551().method_22683();

            originalFramebufferScale = window.method_4489() / window.method_4480();
        });

        URLTextureErrorCallback.EVENT.register((url, error) ->
        {
            UIBaseMenu menu = UIScreen.getCurrentMenu();

            if (menu != null)
            {
                url = url.substring(0, MathUtils.clamp(url.length(), 0, 40));

                if (error == URLError.FFMPEG)
                {
                    menu.context.notifyError(UIKeys.TEXTURE_URL_ERROR_FFMPEG.format(url));
                }
                else if (error == URLError.HTTP_ERROR)
                {
                    menu.context.notifyError(UIKeys.TEXTURE_URL_ERROR_HTTP.format(url));
                }
            }
        });

        BBSRendering.setup();

        /* Network */
        ClientNetwork.setup();

        /* Entity renderers */
        EntityRendererRegistry.register(BBSMod.ACTOR_ENTITY, ActorEntityRenderer::new);
        EntityRendererRegistry.register(BBSMod.GUN_PROJECTILE_ENTITY, GunProjectileEntityRenderer::new);

        BlockEntityRendererRegistryImpl.register(BBSMod.MODEL_BLOCK_ENTITY, ModelBlockEntityRenderer::new);

        BuiltinItemRendererRegistry.INSTANCE.register(BBSMod.MODEL_BLOCK_ITEM, modelBlockItemRenderer);
        BuiltinItemRendererRegistry.INSTANCE.register(BBSMod.GUN_ITEM, gunItemRenderer);

        /* Create folders */
        BBSMod.getAudioFolder().mkdirs();
        BBSMod.getAssetsPath("textures").mkdirs();

        for (String path : List.of("alex", "alex_simple", "steve", "steve_simple"))
        {
            BBSMod.getAssetsPath("models/emoticons/" + path + "/").mkdirs();
        }

        for (String path : List.of("alex", "alex_bends", "eyes", "eyes_1px", "steve", "steve_bends"))
        {
            BBSMod.getAssetsPath("models/player/" + path + "/").mkdirs();
        }

        BBSMod.events.post(new BBSClientReadyEvent());
    }

    private void keyRecordVideo(class_310 mc)
    {
        if (worldExportSession.isExporting())
        {
            worldExportSession.cancel();

            return;
        }

        worldExportSession.start(null, null);
    }

    private class_304 createKey(String id, int key)
    {
        return KeyBindingHelper.registerKeyBinding(new class_304(
            "key." + BBSMod.MOD_ID + "." + id,
            class_3675.class_307.field_1668,
            key,
            "category." + BBSMod.MOD_ID + ".main"
        ));
    }

    private class_304 createKeyMouse(String id, int button)
    {
        return KeyBindingHelper.registerKeyBinding(new class_304(
            "key." + BBSMod.MOD_ID + "." + id,
            class_3675.class_307.field_1672,
            button,
            "category." + BBSMod.MOD_ID + ".main"
        ));
    }

    private void keyOpenModelBlockEditor(class_310 mc)
    {
        class_1799 stack = mc.field_1724.method_6118(class_1304.field_6173);
        ModelBlockItemRenderer.Item item = modelBlockItemRenderer.get(stack);
        GunItemRenderer.Item gunItem = gunItemRenderer.get(stack);

        if (item != null)
        {
            UIScreen.open(new UIModelBlockEditorMenu(item.entity.getProperties()));
        }
        else if (gunItem != null)
        {
            UIScreen.open(new UIModelBlockEditorMenu(gunItem.properties));
        }
    }

    private void keyPlayFilm()
    {
        if (getDashboardIfCreated() == null)
        {
            return;
        }

        UIFilmPanel panel = getDashboard().getPanel(UIFilmPanel.class);
        if (panel.getData() != null)
        {
            Films.playFilm(panel.getData().getId(), false);
        }
    }

    /**
     * Start video recording and film playback together (F6). Recording stops
     * automatically when the film finishes.
     */
    private void keyPlayFilmAndRecord()
    {
        if (getDashboardIfCreated() == null)
        {
            return;
        }

        UIFilmPanel panel = getDashboard().getPanel(UIFilmPanel.class);

        if (panel.getData() == null)
        {
            return;
        }

        String filmId = panel.getData().getId();

        if (worldExportSession.isExporting())
        {
            /* Toggle off only this film's combo; ignore the key while an unrelated recording runs. */
            if (filmId.equals(worldExportSession.getFilmId()))
            {
                worldExportSession.cancel();
            }

            return;
        }

        worldExportSession.start(filmId, panel.getData());
    }

    private void keyPauseFilm()
    {
        if (getDashboardIfCreated() == null)
        {
            return;
        }

        UIFilmPanel panel = getDashboard().getPanel(UIFilmPanel.class);
        if (panel.getData() != null)
        {
            Films.pauseFilm(panel.getData().getId());
        }
    }

    private void keyRecordReplay()
    {
        UIDashboard dashboard = getDashboard();
        UIFilmPanel panel = dashboard.getPanel(UIFilmPanel.class);

        if (panel != null && panel.getData() != null)
        {
            Recorder recorder = getFilms().getRecorder();

            if (recorder != null)
            {
                recorder = BBSModClient.getFilms().stopRecording();

                if (recorder == null || recorder.hasNotStarted() || panel.getData() == null)
                {
                    return;
                }

                panel.applyRecordedKeyframes(recorder, panel.getData());
            }
            else
            {
                Replay replay = panel.replayEditor.getReplay();
                int index = panel.getData().replays.getList().indexOf(replay);

                if (index >= 0)
                {
                    getFilms().startRecording(panel.getData(), index, 0);
                }
            }
        }
    }

    private void keyOpenReplays()
    {
        UIDashboard dashboard = getDashboard();

        UIScreen.open(dashboard);

        if (dashboard.getPanels().panel instanceof UIFilmPanel panel && panel.getData() != null)
        {
            panel.showPanel(panel.replayEditor);
        }
        else
        {
            dashboard.setPanel(dashboard.getPanel(UIFilmPanel.class));
        }
    }

    private void keyTeleport()
    {
        UIDashboard dashboard = getDashboard();
        UIFilmPanel panel = dashboard.getPanel(UIFilmPanel.class);

        if (panel != null)
        {
            panel.replayEditor.teleport();
        }
    }

    public static String getLanguageKey()
    {
        return getLanguageKey(BBSSettings.language.get());
    }

    public static String getLanguageKey(String key)
    {
        if (key.isEmpty())
        {
            key = class_310.method_1551().field_1690.field_1883;
        }

        return key;
    }

    public static void reloadLanguage(String language)
    {
        l10n.reload(language, BBSMod.getProvider());
    }
}
