package mchorse.bbs_mod.blocks.entities;

import mchorse.bbs_mod.data.IMapSerializable;
import mchorse.bbs_mod.data.types.MapType;
import mchorse.bbs_mod.forms.entities.IEntity;
import mchorse.bbs_mod.utils.keyframes.factories.KeyframeFactories;
import net.minecraft.class_1304;
import net.minecraft.class_1799;
import java.util.EnumMap;
import java.util.Map;

/**
 * Equipment worn by a model block: six vanilla slots poured into the block's
 * stub entity every tick, from which the existing armor/held item renderers
 * (both cubic models and mob forms) already know how to draw them.
 */
public class ModelEquipment implements IMapSerializable
{
    private final Map<class_1304, class_1799> stacks = new EnumMap<>(class_1304.class);

    public class_1799 get(class_1304 slot)
    {
        return this.stacks.getOrDefault(slot, class_1799.field_8037);
    }

    public void set(class_1304 slot, class_1799 stack)
    {
        if (stack == null || stack.method_7960())
        {
            this.stacks.remove(slot);
        }
        else
        {
            this.stacks.put(slot, stack);
        }
    }

    public void apply(IEntity entity)
    {
        for (class_1304 slot : class_1304.values())
        {
            entity.setEquipmentStack(slot, this.get(slot));
        }
    }

    @Override
    public void fromData(MapType data)
    {
        this.stacks.clear();

        for (class_1304 slot : class_1304.values())
        {
            if (data.has(slot.method_5923()))
            {
                this.set(slot, KeyframeFactories.ITEM_STACK.fromData(data.get(slot.method_5923())));
            }
        }
    }

    @Override
    public void toData(MapType data)
    {
        for (class_1304 slot : class_1304.values())
        {
            class_1799 stack = this.get(slot);

            if (!stack.method_7960())
            {
                data.put(slot.method_5923(), KeyframeFactories.ITEM_STACK.toData(stack));
            }
        }
    }
}
