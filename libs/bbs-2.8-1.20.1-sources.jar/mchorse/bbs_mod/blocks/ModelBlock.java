package mchorse.bbs_mod.blocks;

import mchorse.bbs_mod.BBSMod;
import mchorse.bbs_mod.blocks.entities.ModelBlockEntity;
import mchorse.bbs_mod.blocks.entities.ModelBody;
import mchorse.bbs_mod.blocks.entities.ModelProperties;
import mchorse.bbs_mod.forms.forms.BlockForm;
import mchorse.bbs_mod.network.ServerNetwork;
import net.minecraft.class_10;
import net.minecraft.class_1264;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1750;
import net.minecraft.class_1799;
import net.minecraft.class_1922;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2343;
import net.minecraft.class_2371;
import net.minecraft.class_238;
import net.minecraft.class_2464;
import net.minecraft.class_2487;
import net.minecraft.class_2498;
import net.minecraft.class_2586;
import net.minecraft.class_259;
import net.minecraft.class_2591;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_2741;
import net.minecraft.class_2754;
import net.minecraft.class_2758;
import net.minecraft.class_3222;
import net.minecraft.class_3419;
import net.minecraft.class_3610;
import net.minecraft.class_3612;
import net.minecraft.class_3726;
import net.minecraft.class_3737;
import net.minecraft.class_3965;
import net.minecraft.class_5558;
import org.jetbrains.annotations.Nullable;

import java.util.function.BooleanSupplier;

public class ModelBlock extends class_2248 implements class_2343, class_3737
{
    public static final class_2758 LIGHT_LEVEL = class_2758.method_11867("light_level", 0, 15);
    public static final class_2754<ModelBlockSound> SOUND = class_2754.method_11850("sound", ModelBlockSound.class);

    /**
     * Client-side hook: whether the player is currently editing (dashboard
     * open, or a model block item in hand). While editing, the outline grows
     * to at least the full cube so a block with a tiny or offset hitbox stays
     * easy to target. On the dedicated server it stays false — the server
     * never targets blocks visually.
     */
    public static BooleanSupplier editingCheck = () -> false;

    public static <E extends class_2586, A extends class_2586> class_5558<A> validateTicker(class_2591<A> givenType, class_2591<E> expectedType, class_5558<? super E> ticker)
    {
        return expectedType == givenType ? (class_5558<A>) ticker : null;
    }

    public ModelBlock(class_2251 settings)
    {
        super(settings);

        this.method_9590(method_9564()
            .method_11657(class_2741.field_12508, false)
            .method_11657(LIGHT_LEVEL, 0)
            .method_11657(SOUND, ModelBlockSound.STONE));
    }

    @Override
    protected void method_9515(class_2689.class_2690<class_2248, class_2680> builder)
    {
        builder.method_11667(class_2741.field_12508, LIGHT_LEVEL, SOUND);
    }

    /**
     * Pushes the body's light level and sound material from the block entity
     * into the block state, where the engine actually reads them. Server side;
     * the state change then syncs to clients on its own.
     */
    public static void mirrorBlockState(class_1937 world, class_2338 pos)
    {
        class_2586 be = world.method_8321(pos);
        class_2680 state = world.method_8320(pos);

        if (!(be instanceof ModelBlockEntity model) || !(state.method_26204() instanceof ModelBlock))
        {
            return;
        }

        ModelBody body = model.getProperties().getBody();
        class_2680 updated = state
            .method_11657(LIGHT_LEVEL, body.getLightLevel())
            .method_11657(SOUND, body.getSound());

        if (updated != state)
        {
            world.method_8652(pos, updated, class_2248.field_31036);
        }
    }

    /** Whether {@link #convert} has anything to turn into a model block here. */
    public static boolean canConvert(class_2680 state)
    {
        return !state.method_26215() && !(state.method_26204() instanceof ModelBlock);
    }

    /**
     * Turn the block at {@code pos} into a model block that shows that same block: a block form
     * with its state, and a body taken from the block — light, sound, hardness, whether it is
     * walked on and its outline as the hitbox — so nothing changes until the user edits it.
     * Neighbours are not updated, so the other half of a door or a torch on its side stay as the
     * set had them. Server side.
     *
     * @return whether the block was swapped
     */
    public static boolean convert(class_1937 world, class_2338 pos)
    {
        class_2680 state = world.method_8320(pos);

        if (!canConvert(state))
        {
            return false;
        }

        /* Everything read off the old block before it is gone */
        boolean waterlogged = state.method_26227().method_39360(class_3612.field_15910);
        int light = state.method_26213();
        class_2498 group = state.method_26231();
        ModelBlockSound sound = ModelBlockSound.of(group);
        float hardness = state.method_26214(world, pos);
        class_265 outline = state.method_26218(world, pos);
        boolean solid = !state.method_26220(world, pos).method_1110();
        boolean camera = !state.method_26202(world, pos, class_3726.method_16194()).method_1110();

        class_2680 modelState = BBSMod.MODEL_BLOCK.method_9564()
            .method_11657(class_2741.field_12508, waterlogged)
            .method_11657(LIGHT_LEVEL, light)
            .method_11657(SOUND, sound);

        if (!world.method_8652(pos, modelState, class_2248.field_31028 | class_2248.field_31031)
            || !(world.method_8321(pos) instanceof ModelBlockEntity model))
        {
            return false;
        }

        /* The water is the model block's now; left in the form it would be drawn twice */
        BlockForm form = new BlockForm();

        form.blockState.set(state.method_28498(class_2741.field_12508) ? state.method_11657(class_2741.field_12508, false) : state);

        ModelProperties properties = model.getProperties();
        ModelBody body = properties.getBody();

        properties.setForm(form);
        body.setLightLevel(light);
        body.setSound(sound);
        body.setHardness(hardness);
        body.setSolid(solid);
        body.setCameraCollision(camera);

        if (!outline.method_1110())
        {
            class_238 box = outline.method_1107();

            if (box.field_1323 != 0 || box.field_1322 != 0 || box.field_1321 != 0 || box.field_1320 != 1 || box.field_1325 != 1 || box.field_1324 != 1)
            {
                body.setHitboxMode(ModelBody.HitboxMode.MANUAL);
                body.getHitboxMin().set((float) box.field_1323, (float) box.field_1322, (float) box.field_1321);
                body.getHitboxMax().set((float) box.field_1320, (float) box.field_1325, (float) box.field_1324);
            }
        }

        model.method_5431();
        world.method_8396(null, pos, group.method_10598(), class_3419.field_15245, (group.method_10597() + 1F) / 2F, group.method_10599() * 0.8F);

        return true;
    }

    @Nullable
    private static ModelBlockEntity getModelBlockEntity(class_1922 world, class_2338 pos)
    {
        return world.method_8321(pos) instanceof ModelBlockEntity model ? model : null;
    }

    /* Shape (the block's hitbox is authored per block in its body settings) */

    @Override
    public class_265 method_9530(class_2680 state, class_1922 world, class_2338 pos, class_3726 context)
    {
        ModelBlockEntity model = getModelBlockEntity(world, pos);
        class_265 shape = model == null ? class_259.method_1077() : model.getShape();

        /* While editing, the block stays targetable as at least a full cube
         * even when its actual hitbox is tiny or offset. CUBE mode returns the
         * fullCube() singleton, so the reference check skips a wasteful union. */
        if (shape != class_259.method_1077() && editingCheck.getAsBoolean())
        {
            return class_259.method_1084(shape, class_259.method_1077());
        }

        return shape;
    }

    @Override
    public class_265 method_9549(class_2680 state, class_1922 world, class_2338 pos, class_3726 context)
    {
        ModelBlockEntity model = getModelBlockEntity(world, pos);

        if (model != null && model.getProperties().getBody().isSolid())
        {
            return model.getShape();
        }

        return class_259.method_1073();
    }

    @Override
    public class_265 method_26159(class_2680 state, class_1922 world, class_2338 pos, class_3726 context)
    {
        ModelBlockEntity model = getModelBlockEntity(world, pos);

        if (model != null && model.getProperties().getBody().isCameraCollision())
        {
            return model.getShape();
        }

        return class_259.method_1073();
    }

    @Override
    public boolean method_9516(class_2680 state, class_1922 world, class_2338 pos, class_10 type)
    {
        ModelBlockEntity model = getModelBlockEntity(world, pos);

        return model == null || !model.getProperties().getBody().isSolid();
    }

    @Override
    public class_2498 method_9573(class_2680 state)
    {
        return state.method_11654(SOUND).group;
    }

    /**
     * Vanilla's break-speed formula, but with the hardness taken from the
     * block's body instead of the registration-time settings — so every model
     * block can take its own time to mine. Runs identically on both sides
     * (the server steps its own break progress), fed by the synced entity.
     */
    @Override
    public float method_9594(class_2680 state, class_1657 player, class_1922 world, class_2338 pos)
    {
        ModelBlockEntity model = getModelBlockEntity(world, pos);
        float hardness = model == null ? 0F : model.getProperties().getBody().getHardness();

        if (hardness <= 0F)
        {
            /* A whole break per tick: the instant break this block always had. */
            return 1F;
        }

        int divisor = player.method_7305(state) ? 30 : 100;

        return player.method_7351(state) / hardness / divisor;
    }

    @Override
    public void method_9567(class_1937 world, class_2338 pos, class_2680 state, class_1309 placer, class_1799 itemStack)
    {
        super.method_9567(world, pos, state, placer, itemStack);

        /* A placed item may carry body data in its BlockEntityTag (already
         * poured into the block entity by now) — mirror it into the state. */
        if (!world.method_8608())
        {
            mirrorBlockState(world, pos);
        }
    }

    @Nullable
    @Override
    public class_2680 method_9605(class_1750 ctx)
    {
        return this.method_9564()
            .method_11657(class_2741.field_12508, ctx.method_8045().method_8316(ctx.method_8037()).method_39360(class_3612.field_15910));
    }

    @Override
    public class_1799 method_9574(class_1922 world, class_2338 pos, class_2680 state)
    {
        class_2586 entity = world.method_8321(pos);

        if (entity instanceof ModelBlockEntity modelBlock)
        {
            class_1799 stack = new class_1799(this);
            class_2487 compound = new class_2487();

            compound.method_10566("BlockEntityTag", modelBlock.method_38243());
            stack.method_7980(compound);

            return stack;
        }

        return super.method_9574(world, pos, state);
    }

    @Override
    public class_2464 method_9604(class_2680 state)
    {
        return class_2464.field_11455;
    }

    @Override
    public boolean method_9579(class_2680 state, class_1922 world, class_2338 pos)
    {
        return true;
    }

    @Nullable
    @Override
    public <T extends class_2586> class_5558<T> method_31645(class_1937 world, class_2680 state, class_2591<T> type)
    {
        if (world.method_8608())
        {
            return validateTicker(type, BBSMod.MODEL_BLOCK_ENTITY, (theWorld, blockPos, blockState, blockEntity) -> blockEntity.tick(theWorld, blockPos, blockState));
        }

        return null;
    }

    @Nullable
    @Override
    public class_2586 method_10123(class_2338 pos, class_2680 state)
    {
        return new ModelBlockEntity(pos, state);
    }

    @Override
    public class_1269 method_9534(class_2680 state, class_1937 world, class_2338 pos, class_1657 player, class_1268 hand, class_3965 hit)
    {
        if (hand == class_1268.field_5808)
        {
            if (player instanceof class_3222 serverPlayer)
            {
                ServerNetwork.sendClickedModelBlock(serverPlayer, pos);
            }

            return class_1269.field_5812;
        }

        return super.method_9534(state, world, pos, player, hand, hit);
    }

    /* Waterloggable implementation */

    @Override
    public class_3610 method_9545(class_2680 state)
    {
        return state.method_11654(class_2741.field_12508) ? class_3612.field_15910.method_15729(false) : super.method_9545(state);
    }

    @Override
    public void method_9556(class_1937 world, class_1657 player, class_2338 pos, class_2680 state, class_2586 be, class_1799 tool)
    {
        if (!world.field_9236 && !player.method_31549().field_7477)
        {
            if (be instanceof ModelBlockEntity model)
            {
                class_1799 stack = new class_1799(this);
                class_2487 wrapper = new class_2487();

                wrapper.method_10566("BlockEntityTag", model.method_38243());
                stack.method_7980(wrapper);

                class_1264.method_17349(world, pos, class_2371.method_10213(1, stack));
            }
        }

        super.method_9556(world, player, pos, state, be, tool);
    }
}