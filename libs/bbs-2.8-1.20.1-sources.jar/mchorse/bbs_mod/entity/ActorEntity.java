package mchorse.bbs_mod.entity;

import mchorse.bbs_mod.forms.entities.MCEntity;
import mchorse.bbs_mod.forms.forms.Form;
import mchorse.bbs_mod.network.ServerNetwork;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1304;
import net.minecraft.class_1306;
import net.minecraft.class_1309;
import net.minecraft.class_1542;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_238;
import net.minecraft.class_2487;
import net.minecraft.class_2775;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_4048;
import net.minecraft.class_4050;
import net.minecraft.class_5132;
import net.minecraft.class_5134;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ActorEntity extends class_1309 implements IEntityFormProvider
{
    public static class_5132.class_5133 createActorAttributes()
    {
        return class_1309.method_26827()
            .method_26868(class_5134.field_23721, 1D)
            .method_26868(class_5134.field_23719, 0.1D)
            .method_26867(class_5134.field_23723)
            .method_26867(class_5134.field_23726);
    }

    private boolean despawn;
    private MCEntity entity = new MCEntity(this);
    private Form form;

    /**
     * Which replay of which film put this body here. A client needs the pairing to know that this
     * entity is a replay's body rather than a creature, and it has to be able to learn that from
     * the entity alone - the map of actors is broadcast when they spawn, which is of no use to
     * anyone who starts seeing one later.
     */
    private String filmId = "";
    private String replayId = "";

    private boolean pickUpItems = true;
    private final List<class_1799> pickedUp = new ArrayList<>();

    private Map<class_1304, class_1799> equipment = new HashMap<>();

    public ActorEntity(class_1299<? extends class_1309> entityType, class_1937 world)
    {
        super(entityType, world);
    }

    public void setReplay(String filmId, String replayId)
    {
        this.filmId = filmId;
        this.replayId = replayId;
    }

    public String getFilmId()
    {
        return this.filmId;
    }

    public String getReplayId()
    {
        return this.replayId;
    }

    public MCEntity getEntity()
    {
        return this.entity;
    }

    @Override
    public int getEntityId()
    {
        return this.method_5628();
    }

    @Override
    public Form getForm()
    {
        return this.form;
    }

    @Override
    public void setForm(Form form)
    {
        Form lastForm = this.form;

        this.form = form;

        if (!this.method_37908().method_8608())
        {
            if (lastForm != null) lastForm.onDemorph(this);
            if (form != null) form.onMorph(this);
        }

        /* The body changed, so the box around it has to change too */
        this.method_18382();
    }

    /**
     * The form's own hitbox, when it declares one. An actor exists so blows land on it, and a box
     * of vanilla's player size around a four-block model means only its ankles can be hit - the
     * flag promised a body in the world and delivered a shin. Same properties the picking box in
     * the editor already reads, so the two agree.
     */
    @Override
    public class_4048 method_18377(class_4050 pose)
    {
        if (this.form == null || !this.form.hitbox.get())
        {
            return super.method_18377(pose);
        }

        float width = this.form.hitboxWidth.get();
        float height = this.form.hitboxHeight.get();

        if (pose == class_4050.field_18081)
        {
            height *= this.form.hitboxSneakMultiplier.get();
        }

        return class_4048.method_18384(width, height);
    }

    @Override
    protected float method_18394(class_4050 pose, class_4048 dimensions)
    {
        if (this.form == null || !this.form.hitbox.get())
        {
            return super.method_18394(pose, dimensions);
        }

        return this.form.hitboxEyeHeight.get();
    }

    @Override
    public boolean method_5640(double distance)
    {
        double d = this.method_5829().method_995();

        if (Double.isNaN(d))
        {
            d = 1D;
        }

        return distance < (d * 256D) * (d * 256D);
    }

    @Override
    public Iterable<class_1799> method_5877()
    {
        return List.of(this.method_6118(class_1304.field_6173), this.method_6118(class_1304.field_6171));
    }

    @Override
    public Iterable<class_1799> method_5661()
    {
        return List.of(this.method_6118(class_1304.field_6166), this.method_6118(class_1304.field_6172), this.method_6118(class_1304.field_6174), this.method_6118(class_1304.field_6169));
    }

    @Override
    public class_1799 method_6118(class_1304 slot)
    {
        return this.equipment.getOrDefault(slot, class_1799.field_8037);
    }

    @Override
    public void method_5673(class_1304 slot, class_1799 stack)
    {
        this.equipment.put(slot, stack == null ? class_1799.field_8037 : stack);
    }

    @Override
    public class_1306 method_6068()
    {
        return class_1306.field_6183;
    }

    @Override
    public void method_5773()
    {
        super.method_5773();

        this.method_6119();

        if (this.form != null)
        {
            this.form.update(this.entity);
        }

        if (this.method_37908().field_9236)
        {
            return;
        }

        if (!this.pickUpItems)
        {
            return;
        }

        /* Pickup items */
        class_238 box = this.method_5829().method_1009(1D, 0.5D, 1D);
        List<class_1297> list = this.method_37908().method_8335(this, box);

        for (class_1297 entity : list)
        {
            if (entity instanceof class_1542 itemEntity)
            {
                class_1799 itemStack = itemEntity.method_6983();
                int i = itemStack.method_7947();

                if (!entity.method_31481() && !itemEntity.method_6977())
                {
                    ((class_3218) this.method_37908()).method_14178().method_18754(entity, new class_2775(entity.method_5628(), this.method_5628(), i));

                    /* Kept, not destroyed: an actor has no inventory to put this in, so what it
                     * swept up used to simply cease to exist - a take rolling near someone's
                     * dropped things ate them. Held until the film stops, then put back. */
                    this.pickedUp.add(itemStack.method_7972());

                    entity.method_31472();
                }
            }
        }
    }

    public void setPickUpItems(boolean pickUpItems)
    {
        this.pickUpItems = pickUpItems;
    }

    /** Put back everything this body swept up, where it now stands. */
    public void dropPickedUp()
    {
        if (this.pickedUp.isEmpty() || this.method_37908().method_8608())
        {
            return;
        }

        for (class_1799 stack : this.pickedUp)
        {
            class_1542 item = new class_1542(this.method_37908(), this.method_23317(), this.method_23318() + 0.5D, this.method_23321(), stack);

            item.method_6988();
            this.method_37908().method_8649(item);
        }

        this.pickedUp.clear();
    }

    @Override
    public void method_5982()
    {
        super.method_5982();

        if (this.despawn)
        {
            this.method_31472();
        }
    }

    @Override
    public void method_5837(class_3222 player)
    {
        super.method_5837(player);

        ServerNetwork.sendEntityForm(player, this);

        /* Who this body belongs to, told to whoever just came within sight of it. The cast map is
         * broadcast when the actors spawn and never again, so a player who joined, changed
         * dimension or simply walked over later had no way of pairing this entity with its replay. */
        if (!this.replayId.isEmpty())
        {
            ServerNetwork.sendActor(player, this.filmId, this.replayId, this.method_5628());
        }
    }

    @Override
    public void method_5749(class_2487 nbt)
    {
        super.method_5749(nbt);

        this.despawn = nbt.method_10577("despawn");
    }

    @Override
    public void method_5652(class_2487 nbt)
    {
        super.method_5652(nbt);

        nbt.method_10556("despawn", true);
    }

    @Override
    protected int method_5691()
    {
        return 4;
    }
}