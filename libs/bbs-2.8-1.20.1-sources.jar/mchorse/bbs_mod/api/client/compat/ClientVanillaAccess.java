package mchorse.bbs_mod.api.client.compat;

import net.minecraft.class_276;
import net.minecraft.class_310;

/**
 * The client half of {@link mchorse.bbs_mod.api.compat.VanillaAccess}.
 *
 * <p>Swapping the game's framebuffer is how BBS renders a film at a size the window is not, and
 * an addon rendering into one of its own needs the same handle. Put back what you took: the game
 * draws into whatever is here when the frame ends.</p>
 */
public final class ClientVanillaAccess
{
    private ClientVanillaAccess()
    {}

    public static class_276 getFramebuffer(class_310 client)
    {
        return client.field_1689;
    }

    public static void setFramebuffer(class_310 client, class_276 framebuffer)
    {
        client.field_1689 = framebuffer;
    }
}
