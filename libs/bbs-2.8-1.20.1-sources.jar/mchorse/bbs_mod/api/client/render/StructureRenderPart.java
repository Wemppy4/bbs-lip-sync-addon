package mchorse.bbs_mod.api.client.render;

import mchorse.bbs_mod.forms.forms.StructureForm;
import mchorse.bbs_mod.forms.renderers.FormRenderingContext;
import mchorse.bbs_mod.forms.renderers.StructureFormRenderer;
import mchorse.bbs_mod.forms.structure.StructureRenderData;
import mchorse.bbs_mod.utils.MatrixStackUtils;
import net.minecraft.class_2338;
import net.minecraft.class_2382;
import net.minecraft.class_2487;
import net.minecraft.class_2680;
import org.joml.Matrix4f;
import org.joml.Vector3f;
import java.util.Map;

/** An independently cached piece of a structure. Uses the normal block, block-entity,
 * shader and picking paths; never mutates the owner's renderer or the shared structure cache.
 * Client-thread only. Recreate when source data/biome changes; resource rebakes are automatic. */
public final class StructureRenderPart
{
    private final PartRenderer renderer;

    public StructureRenderPart(StructureForm owner, StructureRenderData data, String biome, Vector3f offset)
    {
        this.renderer = new PartRenderer(owner, data, biome, offset);
    }

    /** Defensive copies, including block entity NBT and mutable block positions. */
    public static StructureRenderData createData(String id, class_2382 size, Map<class_2338, class_2680> blocks, Map<class_2338, class_2487> entities)
    {
        return StructureRenderData.create(id, size, blocks, entities);
    }

    public void render(FormRenderingContext context, Matrix4f transform)
    {
        context.stack.method_22903();
        if (context.world != null) context.world.method_22903();
        try
        {
            if (transform != null)
            {
                MatrixStackUtils.multiply(context.stack, transform);
                if (context.world != null) MatrixStackUtils.multiply(context.world, transform);
            }
            this.renderer.draw(context);
        }
        finally
        {
            context.stack.method_22909();
            if (context.world != null) context.world.method_22909();
        }
    }

    private static final class PartRenderer extends StructureFormRenderer
    {
        PartRenderer(StructureForm form, StructureRenderData data, String biome, Vector3f offset)
        {
            super(form, data, biome, offset);
        }
        void draw(FormRenderingContext context) { super.render3D(context); }
    }
}
