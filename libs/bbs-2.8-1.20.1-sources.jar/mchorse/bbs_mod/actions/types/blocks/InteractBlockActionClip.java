package mchorse.bbs_mod.actions.types.blocks;

import mchorse.bbs_mod.actions.SuperFakePlayer;
import mchorse.bbs_mod.actions.types.ActionClip;
import mchorse.bbs_mod.actions.values.ValueBlockHitResult;
import mchorse.bbs_mod.film.Film;
import mchorse.bbs_mod.film.replays.Replay;
import mchorse.bbs_mod.settings.values.numeric.ValueBoolean;
import mchorse.bbs_mod.utils.clips.Clip;
import net.minecraft.class_1268;
import net.minecraft.class_1309;
import net.minecraft.class_3965;

public class InteractBlockActionClip extends ActionClip
{
    public final ValueBlockHitResult hit = new ValueBlockHitResult("hit");
    public final ValueBoolean hand = new ValueBoolean("hand", true);

    public InteractBlockActionClip()
    {
        super();

        this.add(this.hit);
        this.add(this.hand);
    }

    @Override
    public void shift(double dx, double dy, double dz)
    {
        super.shift(dx, dy, dz);

        this.hit.shift(dx, dy, dz);
    }

    @Override
    public void applyAction(class_1309 actor, SuperFakePlayer player, Film film, Replay replay, int tick)
    {
        this.applyPositionRotation(player, replay, tick);

        class_3965 result = this.hit.getHitResult();

        player.method_37908().method_8320(result.method_17777()).method_26174(player.method_37908(), player, this.hand.get() ? class_1268.field_5808 : class_1268.field_5810, result);
    }

    /**
     * A container the interaction opened stays open for as long as the clip is
     * long (LUCKYWAY) - the recorder grew it for exactly as long as the player
     * kept the screen up. A clip of a single tick is a tap, a button or a door,
     * and holds nothing open.
     */
    @Override
    public void applyRange(class_1309 actor, SuperFakePlayer player, Film film, Replay replay, int tick)
    {
        if (this.duration.get() > 1)
        {
            player.wantLidOpen(this.hit.getBlockPos());
        }
    }

    @Override
    protected Clip create()
    {
        return new InteractBlockActionClip();
    }
}