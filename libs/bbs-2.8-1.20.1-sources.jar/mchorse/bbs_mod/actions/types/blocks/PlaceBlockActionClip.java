package mchorse.bbs_mod.actions.types.blocks;

import mchorse.bbs_mod.actions.SuperFakePlayer;
import mchorse.bbs_mod.film.Film;
import mchorse.bbs_mod.film.replays.Replay;
import mchorse.bbs_mod.settings.values.mc.ValueBlockState;
import mchorse.bbs_mod.settings.values.numeric.ValueBoolean;
import mchorse.bbs_mod.utils.clips.Clip;
import net.minecraft.class_1309;
import net.minecraft.class_2246;
import net.minecraft.class_2338;

public class PlaceBlockActionClip extends BlockActionClip
{
    public final ValueBlockState state = new ValueBlockState("state");
    public final ValueBoolean drop = new ValueBoolean("drop", false);

    public PlaceBlockActionClip()
    {
        super();

        this.add(this.state);
        this.add(this.drop);
    }

    @Override
    public void applyAction(class_1309 actor, SuperFakePlayer player, Film film, Replay replay, int tick)
    {
        class_2338 pos = new class_2338(this.x.get(), this.y.get(), this.z.get());

        if (this.state.get().method_26204() == class_2246.field_10124)
        {
            player.method_37908().method_22352(pos, this.drop.get());
        }
        else
        {
            player.method_37908().method_8501(pos, this.state.get());
        }
    }

    @Override
    protected Clip create()
    {
        return new PlaceBlockActionClip();
    }
}