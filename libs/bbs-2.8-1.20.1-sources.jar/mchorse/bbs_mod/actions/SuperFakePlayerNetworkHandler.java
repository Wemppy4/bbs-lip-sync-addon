package mchorse.bbs_mod.actions;

import net.minecraft.class_2535;
import net.minecraft.class_2596;
import net.minecraft.class_2598;
import net.minecraft.class_3222;
import net.minecraft.class_3244;
import net.minecraft.class_7648;
import org.jetbrains.annotations.Nullable;

public class SuperFakePlayerNetworkHandler extends class_3244
{
    private static final class_2535 FAKE_CONNECTION = new class_2535(class_2598.field_11942);

    public SuperFakePlayerNetworkHandler(class_3222 player)
    {
        super(player.method_5682(), FAKE_CONNECTION, player);
    }

    @Override
    public void method_14369(class_2596<?> packet, @Nullable class_7648 callbacks)
    {}
}