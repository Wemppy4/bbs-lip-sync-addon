package mchorse.bbs_mod.client;

import mchorse.bbs_mod.BBSMod;
import mchorse.bbs_mod.blocks.ModelBlock;
import mchorse.bbs_mod.graphics.window.Window;
import mchorse.bbs_mod.network.ClientNetwork;
import net.fabricmc.fabric.api.client.item.v1.ItemTooltipCallback;
import net.minecraft.class_124;
import net.minecraft.class_1268;
import net.minecraft.class_1657;
import net.minecraft.class_2338;
import net.minecraft.class_239;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_3965;

/**
 * Alt + right click with a model block in hand turns the block under the crosshair into a model
 * block showing that same block, so a set becomes movable one poke at a time. The swap itself is
 * the server's, see {@link ModelBlock#convert}; creative only, as the server also insists.
 *
 * <p>The click is taken at MinecraftClient.doItemUse (see MinecraftClientMixin), before the item
 * would place a new model block next to the clicked one. While Alt is held every click is taken,
 * even one that converts nothing: poking along a row, a miss must not drop a stray model block or
 * open the dashboard on a block that already is one.</p>
 */
public class ModelBlockConversion
{
    private static final String TOOLTIP = "block.bbs.model.tooltip.convert";

    public static void register()
    {
        ItemTooltipCallback.EVENT.register((stack, context, lines) ->
        {
            if (stack.method_31574(BBSMod.MODEL_BLOCK_ITEM))
            {
                lines.add(class_2561.method_43471(TOOLTIP).method_27692(class_124.field_1080));
            }
        });
    }

    /** True when the click was the conversion's and the item must not be used. */
    public static boolean onUse()
    {
        class_310 mc = class_310.method_1551();
        class_1657 player = mc.field_1724;

        if (player == null || mc.field_1755 != null || !player.method_7337() || !Window.isAltPressed())
        {
            return false;
        }

        class_1268 hand = getHand(player);

        if (hand == null)
        {
            return false;
        }

        if (mc.field_1765 instanceof class_3965 hit && hit.method_17783() == class_239.class_240.field_1332)
        {
            class_2338 pos = hit.method_17777();

            if (ModelBlock.canConvert(mc.field_1687.method_8320(pos)))
            {
                ClientNetwork.sendConvertModelBlock(pos);
                player.method_6104(hand);
            }
        }

        return true;
    }

    private static class_1268 getHand(class_1657 player)
    {
        if (player.method_6047().method_31574(BBSMod.MODEL_BLOCK_ITEM))
        {
            return class_1268.field_5808;
        }

        return player.method_6079().method_31574(BBSMod.MODEL_BLOCK_ITEM) ? class_1268.field_5810 : null;
    }
}
