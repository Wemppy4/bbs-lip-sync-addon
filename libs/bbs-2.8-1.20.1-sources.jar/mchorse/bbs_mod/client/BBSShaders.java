package mchorse.bbs_mod.client;

import mchorse.bbs_mod.BBSMod;
import net.minecraft.class_290;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_3298;
import net.minecraft.class_3300;
import net.minecraft.class_5912;
import net.minecraft.class_5944;
import java.io.IOException;
import java.util.Optional;

public class BBSShaders
{
    private static class_5944 model;
    private static class_5944 multiLink;
    private static class_5944 subtitles;
    private static class_5944 selection;
    private static class_5944 pixelArt;
    private static class_5944 pixelArtText;
    private static class_5944 pixelArtTextIntensity;

    private static class_5944 pickerPreview;
    private static class_5944 pickerBillboard;
    private static class_5944 pickerBillboardNoShading;
    private static class_5944 pickerParticles;
    private static class_5944 pickerModels;

    static
    {
        setup();
    }

    public static void setup()
    {
        if (model != null) model.close();
        if (subtitles != null) subtitles.close();
        if (selection != null) selection.close();
        if (pixelArt != null) pixelArt.close();
        if (pixelArtText != null) pixelArtText.close();
        if (pixelArtTextIntensity != null) pixelArtTextIntensity.close();

        if (pickerPreview != null) pickerPreview.close();
        if (pickerBillboard != null) pickerBillboard.close();
        if (pickerBillboardNoShading != null) pickerBillboardNoShading.close();
        if (pickerParticles != null) pickerParticles.close();
        if (pickerModels != null) pickerModels.close();

        try
        {
            class_5912 factory = new ProxyResourceFactory(class_310.method_1551().method_1478());

            model = new class_5944(factory, "model", class_290.field_1580);
            multiLink = new class_5944(factory, "multilink", class_290.field_1575);
            subtitles = new class_5944(factory, "subtitles", class_290.field_1575);
            selection = new class_5944(factory, "selection", class_290.field_1575);

            pickerPreview = new class_5944(factory, "picker_preview", class_290.field_1575);
            pickerBillboard = new class_5944(factory, "picker_billboard", class_290.field_1580);
            pickerBillboardNoShading = new class_5944(factory, "picker_billboard_no_shading", class_290.field_1586);
            pickerParticles = new class_5944(factory, "picker_particles", class_290.field_20888);
            pickerModels = new class_5944(factory, "picker_models", class_290.field_1580);
        }
        catch (IOException e)
        {
            e.printStackTrace();
        }

        /* Kept in a try of their own: these are a cosmetic nicety, and a driver
         * that refuses to compile them must not take the shaders the editor
         * can't work without (bone picking, models) down with them. Everything
         * asking for these falls back to vanilla's programs when they're null. */
        try
        {
            class_5912 factory = new ProxyResourceFactory(class_310.method_1551().method_1478());

            pixelArt = new class_5944(factory, "pixelart", class_290.field_1575);
            pixelArtText = new class_5944(factory, "pixelart_text", class_290.field_20888);
            pixelArtTextIntensity = new class_5944(factory, "pixelart_text_intensity", class_290.field_20888);
        }
        catch (IOException e)
        {
            /* All or nothing: text must not end up half swapped */
            if (pixelArt != null) pixelArt.close();
            if (pixelArtText != null) pixelArtText.close();
            if (pixelArtTextIntensity != null) pixelArtTextIntensity.close();

            pixelArt = pixelArtText = pixelArtTextIntensity = null;

            e.printStackTrace();
        }
    }

    public static class_5944 getModel()
    {
        return model;
    }

    public static class_5944 getMultilinkProgram()
    {
        return multiLink;
    }

    public static class_5944 getSubtitlesProgram()
    {
        return subtitles;
    }

    public static class_5944 getSelectionProgram()
    {
        return selection;
    }

    /**
     * Textured UI quads with the seam between texels smoothed, for when the
     * interface is drawn at a fractional scale (see the shader's own comment).
     */
    public static class_5944 getPixelArtProgram()
    {
        return pixelArt;
    }

    public static class_5944 getPixelArtTextProgram()
    {
        return pixelArtText;
    }

    public static class_5944 getPixelArtTextIntensityProgram()
    {
        return pixelArtTextIntensity;
    }

    public static class_5944 getPickerPreviewProgram()
    {
        return pickerPreview;
    }

    public static class_5944 getPickerBillboardProgram()
    {
        return pickerBillboard;
    }

    public static class_5944 getPickerBillboardNoShadingProgram()
    {
        return pickerBillboardNoShading;
    }

    public static class_5944 getPickerParticlesProgram()
    {
        return pickerParticles;
    }

    public static class_5944 getPickerModelsProgram()
    {
        return pickerModels;
    }

    private static class ProxyResourceFactory implements class_5912
    {
        private class_3300 manager;

        public ProxyResourceFactory(class_3300 manager)
        {
            this.manager = manager;
        }

        @Override
        public Optional<class_3298> method_14486(class_2960 id)
        {
            if (id.method_12832().contains("/core/"))
            {
                return this.manager.method_14486(new class_2960(BBSMod.MOD_ID, id.method_12832()));
            }

            /* #moj_import always resolves in the minecraft namespace, so our own
             * includes have to be looked up in BBS first, vanilla's second */
            if (id.method_12832().contains("/include/"))
            {
                Optional<class_3298> resource = this.manager.method_14486(new class_2960(BBSMod.MOD_ID, id.method_12832()));

                if (resource.isPresent())
                {
                    return resource;
                }
            }

            return this.manager.method_14486(id);
        }
    }
}
