package mchorse.bbs_mod.forms;

import mchorse.bbs_mod.forms.forms.SplineForm;
import mchorse.bbs_mod.forms.renderers.SplineFormRenderer;

import com.mojang.logging.LogUtils;
import it.unimi.dsi.fastutil.objects.Object2ObjectLinkedOpenHashMap;
import mchorse.bbs_mod.forms.forms.AnchorForm;
import mchorse.bbs_mod.forms.forms.BillboardForm;
import mchorse.bbs_mod.forms.forms.BlockForm;
import mchorse.bbs_mod.forms.forms.ExtrudedForm;
import mchorse.bbs_mod.cubic.IBoneHierarchy;
import mchorse.bbs_mod.forms.forms.Form;
import mchorse.bbs_mod.forms.forms.FramebufferForm;
import mchorse.bbs_mod.forms.forms.ItemForm;
import mchorse.bbs_mod.forms.forms.LabelForm;
import mchorse.bbs_mod.forms.forms.MobForm;
import mchorse.bbs_mod.forms.forms.ModelForm;
import mchorse.bbs_mod.forms.forms.ParticleForm;
import mchorse.bbs_mod.forms.forms.StructureForm;
import mchorse.bbs_mod.forms.forms.TrailForm;
import mchorse.bbs_mod.forms.forms.VanillaParticleForm;
import mchorse.bbs_mod.forms.forms.VideoForm;
import mchorse.bbs_mod.forms.renderers.AnchorFormRenderer;
import mchorse.bbs_mod.forms.renderers.BillboardFormRenderer;
import mchorse.bbs_mod.forms.renderers.BlockFormRenderer;
import mchorse.bbs_mod.forms.renderers.ExtrudedFormRenderer;
import mchorse.bbs_mod.forms.renderers.FormRenderer;
import mchorse.bbs_mod.utils.profiler.BBSProfiler;
import net.minecraft.class_1088;
import net.minecraft.class_156;
import net.minecraft.class_1921;
import net.minecraft.class_287;
import net.minecraft.class_4722;
import net.minecraft.class_750;
import mchorse.bbs_mod.api.client.events.FormRenderEvents;
import mchorse.bbs_mod.forms.renderers.FormRenderingContext;
import mchorse.bbs_mod.forms.renderers.FramebufferFormRenderer;
import mchorse.bbs_mod.forms.renderers.ItemFormRenderer;
import mchorse.bbs_mod.forms.renderers.LabelFormRenderer;
import mchorse.bbs_mod.forms.renderers.MobFormRenderer;
import mchorse.bbs_mod.forms.renderers.ModelFormRenderer;
import mchorse.bbs_mod.forms.renderers.ParticleFormRenderer;
import mchorse.bbs_mod.forms.renderers.StructureFormRenderer;
import mchorse.bbs_mod.forms.renderers.TrailFormRenderer;
import mchorse.bbs_mod.forms.renderers.VanillaParticleFormRenderer;
import mchorse.bbs_mod.forms.renderers.VideoFormRenderer;
import mchorse.bbs_mod.forms.structure.BakedStructure;
import mchorse.bbs_mod.ui.framework.UIContext;
import org.slf4j.Logger;

import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.SortedMap;
import java.util.Stack;

public class FormUtilsClient
{
    private static final Logger LOGGER = LogUtils.getLogger();

    /**
     * Render failures already reported, keyed by form class, exception class and throw
     * site. Rendering runs every frame, so an unguarded log buries the game in one
     * repeating stack trace — which is why this used to be a silent catch, and why
     * thousands of lines of IK, physics and material code could fail invisibly.
     */
    private static final Set<String> reportedRenderFailures = new HashSet<>();

    private static Map<Class, IFormRendererFactory> map = new HashMap<>();
    private static CustomVertexConsumerProvider customVertexConsumerProvider;
    private static Stack<Form> currentForm = new Stack<>();

    private static CustomVertexConsumerProvider createProvider()
    {
        class_750 storage = new class_750();
        SortedMap sortedMap = class_156.method_654(new Object2ObjectLinkedOpenHashMap(), map -> {
            map.put(class_4722.method_24073(), storage.method_3154(class_1921.method_23577()));
            map.put(class_4722.method_24074(), storage.method_3154(class_1921.method_23581()));
            map.put(class_4722.method_24059(), storage.method_3154(class_1921.method_23579()));
            /* Dedicated buffers for the terrain block layers, so forms that render real blocks (the
             * structure form) get them keyed — drawn together at draw() with correct depth — instead
             * of falling through to the shared fallback buffer, which flushes on every layer switch
             * and loses depth between opaque layers (e.g. cutout leaves drawing over solid blocks).
             * Kept before the translucent layer so opaque draws first. Empty for forms that don't
             * use terrain layers. */
            assignBufferBuilder(map, class_1921.method_23577());
            assignBufferBuilder(map, class_1921.method_23581());
            assignBufferBuilder(map, class_1921.method_23579());
            map.put(class_4722.method_24076(), storage.method_3154(class_1921.method_23583()));
            /* Right behind the layer it stands in for while a block form carries a color overlay,
             * so the swap does not move when the geometry draws. */
            assignBufferBuilder(map, BlockFormRenderer.OVERLAY_TRANSLUCENT_LAYER);
            assignBufferBuilder(map, class_4722.method_24067());
            assignBufferBuilder(map, class_4722.method_24069());
            assignBufferBuilder(map, class_4722.method_24070());
            assignBufferBuilder(map, class_4722.method_24071());
            assignBufferBuilder(map, class_4722.method_45783());
            map.put(class_4722.method_24072(), new class_287(786432));
            assignBufferBuilder(map, class_1921.method_27948());
            assignBufferBuilder(map, class_1921.method_27949());
            assignBufferBuilder(map, class_1921.method_23590());
            assignBufferBuilder(map, class_1921.method_29706());
            assignBufferBuilder(map, class_1921.method_30676());
            assignBufferBuilder(map, class_1921.method_23591());
            assignBufferBuilder(map, class_1921.method_29707());
            assignBufferBuilder(map, class_1921.method_23589());
            class_1088.field_21772.forEach(renderLayer -> assignBufferBuilder(map, renderLayer));
            /* Last: the structure form's color overlay is a second pass over the whole structure,
             * so it has to flush after every layer the structure itself drew into. */
            assignBufferBuilder(map, BakedStructure.OVERLAY_LAYER);
        });

        return new CustomVertexConsumerProvider(new class_287(1536), sortedMap);
    }

    /**
     * Fills the registry. Called by BBS while it initialises, and followed by the event that
     * lets addons add to it.
     *
     * <p>This used to be a static initialiser, which ran whenever something first touched the
     * class — a moment nobody chose and an addon could not aim at.</p>
     */
    public static void setup()
    {
        register(BillboardForm.class, BillboardFormRenderer::new);
        register(VideoForm.class, VideoFormRenderer::new);
        register(ExtrudedForm.class, ExtrudedFormRenderer::new);
        register(LabelForm.class, LabelFormRenderer::new);
        register(ModelForm.class, ModelFormRenderer::new);
        register(ParticleForm.class, ParticleFormRenderer::new);
        register(BlockForm.class, BlockFormRenderer::new);
        register(ItemForm.class, ItemFormRenderer::new);
        register(AnchorForm.class, AnchorFormRenderer::new);
        register(SplineForm.class, SplineFormRenderer::new);
        register(MobForm.class, MobFormRenderer::new);
        register(VanillaParticleForm.class, VanillaParticleFormRenderer::new);
        register(TrailForm.class, TrailFormRenderer::new);
        register(FramebufferForm.class, FramebufferFormRenderer::new);
        register(StructureForm.class, StructureFormRenderer::new);
    }

    private static void assignBufferBuilder(Object2ObjectLinkedOpenHashMap<class_1921, class_287> builderStorage, class_1921 layer)
    {
        builderStorage.put(layer, new class_287(layer.method_22722()));
    }

    public static CustomVertexConsumerProvider getProvider()
    {
        /* Built on first use rather than while the mod initialises: it allocates the render
         * layers' buffers, and doing that before the game is ready is the kind of thing that
         * goes wrong in the game instead of in the build. */
        if (customVertexConsumerProvider == null)
        {
            customVertexConsumerProvider = createProvider();
        }

        return customVertexConsumerProvider;
    }

    public static <T extends Form> void register(Class<T> clazz, IFormRendererFactory<T> function)
    {
        map.put(clazz, function);
    }

    /**
     * The renderer registered for a form's own class, or for the nearest class it extends.
     *
     * <p>Without the walk up, extending one of BBS's forms bought nothing: the subclass
     * inherited the shape and the data and then drew as nothing at all, until it registered a
     * renderer that was usually a copy of its parent's.</p>
     */
    private static IFormRendererFactory findFactory(Class clazz)
    {
        while (clazz != null && clazz != Object.class)
        {
            IFormRendererFactory factory = map.get(clazz);

            if (factory != null)
            {
                return factory;
            }

            clazz = clazz.getSuperclass();
        }

        return null;
    }

    public static Form getCurrentForm()
    {
        return currentForm.isEmpty() ? null : currentForm.peek();
    }

    public static FormRenderer getRenderer(Form form)
    {
        if (form == null)
        {
            return null;
        }

        if (form.getRenderer() instanceof FormRenderer renderer)
        {
            return renderer;
        }

        IFormRendererFactory factory = findFactory(form.getClass());

        if (factory != null)
        {
            FormRenderer formRenderer = factory.create(form);

            form.setRenderer(formRenderer);

            return formRenderer;
        }

        return null;
    }

    public static void renderUI(Form form, UIContext context, int x1, int y1, int x2, int y2)
    {
        BBSProfiler.count(BBSProfiler.Section.UI_PREVIEW_RENDERS);
        BBSProfiler.begin(BBSProfiler.Timer.UI_PREVIEWS);

        FormRenderer renderer = getRenderer(form);

        if (renderer != null)
        {
            renderer.renderUI(context, x1, y1, x2, y2);
        }

        BBSProfiler.end(BBSProfiler.Timer.UI_PREVIEWS);
    }

    /** The form's picture alone; see {@link FormRenderer#renderPreview}. */
    public static void renderPreview(Form form, UIContext context, int x1, int y1, int x2, int y2)
    {
        BBSProfiler.count(BBSProfiler.Section.UI_PREVIEW_RENDERS);
        BBSProfiler.begin(BBSProfiler.Timer.UI_PREVIEWS);

        FormRenderer renderer = getRenderer(form);

        if (renderer != null)
        {
            renderer.renderPreview(context, x1, y1, x2, y2);
        }

        BBSProfiler.end(BBSProfiler.Timer.UI_PREVIEWS);
    }

    public static void render(Form form, FormRenderingContext context)
    {
        /* A form set to render last skips its turn here and draws when the pass closes its
         * scope — through this very method, so the events fire once, at the real draw. */
        if (FormRenderLast.postpone(form, context))
        {
            return;
        }

        FormRenderer renderer = getRenderer(form);

        if (renderer != null)
        {
            currentForm.push(form);

            FormRenderEvents.BEFORE.invoker().onFormRender(form, context);

            try
            {
                renderer.render(context);
            }
            catch (Exception e)
            {
                reportRenderFailure(form, e);
            }

            /* After the catch, so a listener that pushed something in BEFORE still gets to
             * pop it when the form's own renderer threw. */
            FormRenderEvents.AFTER.invoker().onFormRender(form, context);

            currentForm.pop();
        }
    }

    /**
     * Reports the first occurrence of each distinct render failure and drops the repeats.
     * The frame is still let through: a form that throws must not take the rest of the
     * scene with it, which is what the swallow was for.
     */
    private static void reportRenderFailure(Form form, Exception e)
    {
        StackTraceElement[] trace = e.getStackTrace();
        String key = form.getClass().getName() + "|" + e.getClass().getName() + "|" + (trace.length == 0 ? "" : trace[0].toString());

        if (reportedRenderFailures.add(key))
        {
            LOGGER.error("[BBS form] {} failed to render - further repeats of this failure are silenced.", form.getClass().getSimpleName(), e);
        }
    }

    public static IBoneHierarchy getBoneHierarchy(Form form)
    {
        FormRenderer renderer = getRenderer(form);

        return renderer == null ? null : renderer.getBoneHierarchy();
    }

    public static List<String> getBones(Form form)
    {
        FormRenderer renderer = getRenderer(form);

        if (renderer != null)
        {
            return renderer.getBones();
        }

        return Collections.emptyList();
    }

    public static interface IFormRendererFactory <T extends Form>
    {
        public FormRenderer<T> create(T form);
    }
}
